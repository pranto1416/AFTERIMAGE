// AFTERIMAGE song scanner — reads a whole track before (and while) it plays,
// and turns it into a map: overall mood, atmosphere and a chapter-by-chapter journey.
// It reproduces the browser AnalyserNode's maths (Blackman window, smoothing, dB scale)
// so the numbers line up with live listening.
import { buildJourney, pickMood, classifyAtmosphere, clamp } from './core.js';

const N = 2048;
const HALF = N / 2;
const MIN_DB = -100, RANGE_DB = 70;
const SMOOTH = 0.55;
const HOP_SEC = 0.05;

let tables = null;
function getTables() {
  if (tables) return tables;
  const rev = new Uint32Array(N);
  const bits = Math.log2(N);
  for (let i = 0; i < N; i++) {
    let r = 0;
    for (let b = 0; b < bits; b++) r |= ((i >> b) & 1) << (bits - 1 - b);
    rev[i] = r;
  }
  const cos = new Float32Array(HALF), sin = new Float32Array(HALF);
  for (let i = 0; i < HALF; i++) { cos[i] = Math.cos((2 * Math.PI * i) / N); sin[i] = -Math.sin((2 * Math.PI * i) / N); }
  const win = new Float32Array(N);
  for (let i = 0; i < N; i++) {
    const x = i / N;
    win[i] = 0.42 - 0.5 * Math.cos(2 * Math.PI * x) + 0.08 * Math.cos(4 * Math.PI * x);
  }
  tables = { rev, cos, sin, win };
  return tables;
}

/** In-place radix-2 FFT of length N. */
export function fft(re, im) {
  const { rev, cos, sin } = getTables();
  for (let i = 0; i < N; i++) {
    const j = rev[i];
    if (j > i) { let t = re[i]; re[i] = re[j]; re[j] = t; t = im[i]; im[i] = im[j]; im[j] = t; }
  }
  for (let size = 2; size <= N; size <<= 1) {
    const half = size >> 1, step = N / size;
    for (let start = 0; start < N; start += size) {
      for (let k = 0; k < half; k++) {
        const wr = cos[k * step], wi = sin[k * step];
        const a = start + k, b = a + half;
        const tr = re[b] * wr - im[b] * wi, ti = re[b] * wi + im[b] * wr;
        re[b] = re[a] - tr; im[b] = im[a] - ti;
        re[a] += tr; im[a] += ti;
      }
    }
  }
}

const mean = (a) => (a.length ? a.reduce((s, x) => s + x, 0) / a.length : 0);
const std = (a) => { const m = mean(a); return Math.sqrt(mean(a.map((x) => (x - m) ** 2))); };
const movingAvg = (a, w) => a.map((_, i) => mean(a.slice(Math.max(0, i - w), Math.min(a.length, i + w + 1))));

/** Spectral flatness of linear magnitudes: 1 = noise, ~0 = pure tones. */
export function flatness(mags, i0, i1) {
  let logSum = 0, sum = 0, n = 0;
  for (let i = i0; i < i1; i++) { const m = mags[i] + 1e-9; logSum += Math.log(m); sum += m; n++; }
  return n ? Math.exp(logSum / n) / (sum / n) : 0;
}

/**
 * Analyse a mono signal. Yields to the browser regularly so playback stays smooth.
 * Returns a SongMap.
 */
export async function scanSong(mono, sampleRate, { onProgress, shouldStop } = {}) {
  const { win } = getTables();
  const hop = Math.max(1, Math.round(sampleRate * HOP_SEC));
  const frames = Math.max(0, Math.floor((mono.length - N) / hop));
  const binHz = sampleRate / N;
  const re = new Float32Array(N), im = new Float32Array(N);
  const sm = new Float32Array(HALF), v = new Float32Array(HALF), prev = new Float32Array(HALF);
  const bin = (hz) => Math.min(HALF - 1, Math.max(1, Math.round(hz / binHz)));
  const band = (lo, hi) => { const a = bin(lo), b = bin(hi); let s = 0; for (let i = a; i <= b; i++) s += v[i]; return s / (b - a + 1); };
  const topFlux = bin(2500), topCen = bin(11000), topFlat = bin(8000);

  const loud = new Float32Array(frames), cen = new Float32Array(frames), bass = new Float32Array(frames),
    mid = new Float32Array(frames), flat = new Float32Array(frames), onset = new Uint8Array(frames);
  let fluxAvg = 0, since = 1;

  for (let f = 0; f < frames; f++) {
    const off = f * hop;
    let rms = 0;
    for (let i = 0; i < N; i++) { const x = mono[off + i]; rms += x * x; re[i] = x * win[i]; im[i] = 0; }
    fft(re, im);
    for (let k = 0; k < HALF; k++) {
      const m = Math.hypot(re[k], im[k]) / N;
      sm[k] = SMOOTH * sm[k] + (1 - SMOOTH) * m;
      v[k] = clamp((20 * Math.log10(sm[k] + 1e-12) - MIN_DB) / RANGE_DB, 0, 1);
    }
    loud[f] = Math.min(1, Math.sqrt(rms / N) * 3.2);
    bass[f] = band(30, 160);
    mid[f] = band(300, 2000);
    let num = 0, den = 0;
    for (let k = 1; k < topCen; k++) { num += k * v[k]; den += v[k]; }
    cen[f] = den > 0 ? (num / den) * binHz : 0;
    flat[f] = flatness(sm, 2, topFlat);
    let flux = 0;
    for (let k = 1; k < topFlux; k++) { const d = v[k] - prev[k]; if (d > 0) flux += d; prev[k] = v[k]; }
    flux /= topFlux;
    fluxAvg += (flux - fluxAvg) * (1 - Math.exp(-HOP_SEC * 2.5));
    since += HOP_SEC;
    if (flux > fluxAvg * 1.55 + 0.006 && since > 0.11) { onset[f] = 1; since = 0; }
    if (f % 400 === 0) {
      if (shouldStop && shouldStop()) return null;
      if (onProgress) onProgress(f / Math.max(1, frames));
      await new Promise((r) => setTimeout(r, 0));
    }
  }

  // One value per second.
  const fps = Math.round(1 / HOP_SEC);
  const secs = Math.max(1, Math.ceil(frames / fps));
  const perSec = { e: [], b: [], o: [], w: [], flat: [], loud: [] };
  for (let s = 0; s < secs; s++) {
    const a = s * fps, b = Math.min(frames, a + fps);
    let L = 0, C = 0, Bs = 0, M = 0, F = 0, O = 0;
    for (let f = a; f < b; f++) { L += loud[f]; C += cen[f]; Bs += bass[f]; M += mid[f]; F += flat[f]; O += onset[f]; }
    const n = Math.max(1, b - a);
    perSec.loud.push(L / n);
    perSec.e.push(Math.min(1, (L / n) * 1.15));
    perSec.b.push(clamp((C / n - 600) / 3400, 0, 1));
    perSec.w.push((Bs / n) / ((Bs / n) + (M / n) + 1e-4));
    perSec.flat.push(F / n);
    perSec.o.push(O);
  }
  perSec.o = movingAvg(perSec.o, 3).map((x) => Math.min(1, x / 5));

  const audible = perSec.loud.map((l, i) => (l >= 0.03 ? i : -1)).filter((i) => i >= 0);
  const pick = (k) => mean(audible.map((i) => perSec[k][i]));
  const stats = { e: pick('e'), b: pick('b'), o: pick('o'), w: pick('w') };
  const b10 = movingAvg(audible.map((i) => perSec.b[i]), 5);
  const e10 = movingAvg(audible.map((i) => perSec.e[i]), 5);
  const duration = mono.length / sampleRate;
  const atmoStats = {
    e: stats.e, b: stats.b, flat: pick('flat'),
    vari: clamp((std(b10) + std(e10)) * 2.2, 0, 1),
    long: clamp((duration - 240) / 360, 0, 1),
  };

  const envelope = new Float32Array(240);
  for (let i = 0; i < 240; i++) {
    const a = Math.floor((i / 240) * frames), b = Math.max(a + 1, Math.floor(((i + 1) / 240) * frames));
    let mx = 0;
    for (let f = a; f < b && f < frames; f++) mx = Math.max(mx, loud[f]);
    envelope[i] = mx;
  }
  const peak = Math.max(1e-3, ...envelope);
  for (let i = 0; i < 240; i++) envelope[i] /= peak;

  if (onProgress) onProgress(1);
  return {
    duration,
    stats,
    atmoStats,
    env: pickMood(stats),
    atmo: classifyAtmosphere(atmoStats),
    journey: buildJourney(perSec),
    envelope,
  };
}
