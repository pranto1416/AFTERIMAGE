// AFTERIMAGE render engine — Three.js scene, custom GLSL, feedback trails, bloom.
import * as THREE from 'https://cdn.jsdelivr.net/npm/three@0.160.0/build/three.module.js';
import { knotFor, hashString, mulberry32 } from './core.js';
import { NOISE } from './glsl.js';
import { Landscapes } from './env.js';

// ---------- Palettes (sRGB hex; converted to linear by THREE.Color) ----------
export const PALETTE_DEFS = {
  mono:    { name: 'Monochrome', bg: 0x030304, base: 0x101114, mid: 0x8f949c, acc: 0xffffff, rim: 0xdde4ee, dustA: 0x9aa0aa, dustB: 0xffffff },
  ice:     { name: 'Ice',        bg: 0x010407, base: 0x05141c, mid: 0x4f9fc2, acc: 0xc4f6ff, rim: 0x33e1ff, dustA: 0x2a8fb8, dustB: 0xd9fbff },
  violet:  { name: 'Violet',     bg: 0x030208, base: 0x0b0716, mid: 0x6248d0, acc: 0xeadcff, rim: 0xa874ff, dustA: 0x6d4fe0, dustB: 0xd9c8ff },
  inferno: { name: 'Inferno',    bg: 0x060202, base: 0x140504, mid: 0xc23d0e, acc: 0xffd9a0, rim: 0xff3d6e, dustA: 0xff5a1f, dustB: 0xffd28a },
};

// ---------- GLSL ----------


const SCULPT_VERT = /* glsl */`
uniform float uTime, uBass, uMidE, uTreble, uKick, uDeform, uFreq, uSharp, uWarp, uFlow, uDetail, uAmp;
varying vec3 vWorldPos;
varying vec3 vNormalW;
varying float vDisp;
varying vec3 vObj;
${NOISE}
float ridge(float n){ return 1.0 - 2.0*abs(n); }
float field(vec3 p){
  vec3 q = p;
  q.xz = rot2(uWarp * (1.6*q.y + 0.5*sin(uTime*0.27))) * q.xz;
  q.x += uWarp * 0.35 * sin(q.y*2.3 + uTime*0.4);
  float t = uTime;
  vec3 w = vec3(
    snoise(q*0.9 + vec3(0.0, t*0.13, 0.0)),
    snoise(q*0.9 + vec3(17.3, -t*0.11, 4.1)),
    snoise(q*0.9 + vec3(-9.2, 3.7, t*0.12)));
  q += uFlow * 0.45 * w;
  float nL = snoise(q*uFreq*0.55 + vec3(0.0, t*0.18, 0.0));
  float nM = snoise(q*uFreq*1.6 + vec3(t*0.31));
  float nH = snoise(q*uFreq*4.8 - vec3(t*0.45));
  nL = mix(nL, ridge(nL), uSharp);
  nM = mix(nM, ridge(nM), uSharp);
  float d = nL*(0.10 + 0.42*uBass) + nM*(0.035 + 0.2*uMidE) + nH*(0.008 + 0.07*uTreble)*(0.35 + uDetail);
  d *= uDeform;
  d += 0.035*sin(t*1.1 + p.y*1.5) + uKick*0.06;
  return d * uAmp;
}
void main(){
  vec3 p = position;
  vec3 n = normalize(normal);
  vec3 tA = normalize(cross(n, abs(n.y) < 0.98 ? vec3(0.0,1.0,0.0) : vec3(1.0,0.0,0.0)));
  vec3 tB = cross(n, tA);
  float e = 0.012;
  float d0 = field(p);
  vec3 P0 = p + n*d0;
  vec3 P1 = p + tA*e + n*field(p + tA*e);
  vec3 P2 = p + tB*e + n*field(p + tB*e);
  vec3 nn = normalize(cross(P1 - P0, P2 - P0));
  if (dot(nn, n) < 0.0) nn = -nn;
  vDisp = d0 / max(uAmp, 0.001);
  vObj = p;
  vec4 wp = modelMatrix * vec4(P0, 1.0);
  vWorldPos = wp.xyz;
  vNormalW = normalize(mat3(modelMatrix) * nn);
  gl_Position = projectionMatrix * viewMatrix * wp;
}`;

const SCULPT_FRAG = /* glsl */`
uniform vec3 uColBase, uColMid, uColAcc, uColRim;
uniform float uTime, uMidE, uTreble, uKick, uSharp, uFade, uFlat, uDark;
varying vec3 vWorldPos;
varying vec3 vNormalW;
varying float vDisp;
varying vec3 vObj;
void main(){
  vec3 V = normalize(cameraPosition - vWorldPos);
  vec3 N = normalize(vNormalW);
  vec3 fN = normalize(cross(dFdx(vWorldPos), dFdy(vWorldPos)));
  if (dot(fN, V) < 0.0) fN = -fN;
  N = normalize(mix(N, fN, uFlat));
  if (dot(N, V) < 0.0) N = -N;
  float ndv = clamp(dot(N, V), 0.0, 1.0);
  float fres = pow(1.0 - ndv, mix(3.2, 1.8, uTreble));
  vec3 L = normalize(vec3(0.5, 0.85, 0.45));
  vec3 L2 = normalize(vec3(-0.7, -0.2, -0.5));
  float diff = max(dot(N, L), 0.0)*0.85 + max(dot(N, L2), 0.0)*0.25;
  float spec = pow(max(dot(reflect(-L, N), V), 0.0), 20.0 + 80.0*uSharp);
  float h = smoothstep(-0.25, 0.35, vDisp);
  vec3 col = mix(uColBase, uColMid, h) * (0.18 + 0.82*diff);
  col += uColAcc * spec * (0.5 + 1.2*uSharp);
  col += uColRim * fres * (0.55 + 1.3*uMidE + 1.6*uKick);
  float bands = sin(vDisp*55.0 + uTime*3.0 + vObj.y*6.0);
  col += uColRim * 0.22 * uTreble * smoothstep(0.6, 1.0, bands) * (0.3 + fres);
  vec3 voidCol = uColRim * fres*fres * (1.4 + 1.5*uKick) + uColAcc * spec * 0.25 + uColBase * 0.04;
  col = mix(col, voidCol, uDark);
  gl_FragColor = vec4(col * uFade, 1.0);
}`;

const SHARD_VERT = /* glsl */`
uniform float uTime, uTreble, uKick;
varying vec3 vWorldPos;
varying float vSeed;
void main(){
  vec3 p = position * (1.0 + 0.6*uTreble + 0.4*uKick);
  #ifdef USE_INSTANCING
    vec4 wp = modelMatrix * instanceMatrix * vec4(p, 1.0);
    vSeed = fract(instanceMatrix[3].x * 7.13 + instanceMatrix[3].z * 3.7);
  #else
    vec4 wp = modelMatrix * vec4(p, 1.0);
    vSeed = 0.5;
  #endif
  vWorldPos = wp.xyz;
  gl_Position = projectionMatrix * viewMatrix * wp;
}`;

const SHARD_FRAG = /* glsl */`
uniform vec3 uColMid, uColAcc, uColRim;
uniform float uTime, uTreble, uKick, uFade, uShow;
varying vec3 vWorldPos;
varying float vSeed;
void main(){
  vec3 V = normalize(cameraPosition - vWorldPos);
  vec3 N = normalize(cross(dFdx(vWorldPos), dFdy(vWorldPos)));
  if (dot(N, V) < 0.0) N = -N;
  float fres = pow(1.0 - clamp(dot(N, V), 0.0, 1.0), 2.0);
  float glint = pow(max(dot(N, normalize(vec3(0.4, 0.9, 0.3))), 0.0), 18.0);
  float flick = 0.6 + 0.4*sin(uTime*2.0 + vSeed*40.0);
  vec3 col = uColMid*0.15 + uColRim*fres*(0.8 + 1.5*uTreble) + uColAcc*glint*(0.6 + 2.0*uKick);
  gl_FragColor = vec4(col * flick * uFade * uShow, 1.0);
}`;

const POINTS_VERT = /* glsl */`
attribute float aSeed;
uniform float uTime, uBass, uSize, uSwirl, uPix, uLift;
varying float vSeed;
void main(){
  vec3 p = position;
  float r = length(p.xz);
  float a = atan(p.z, p.x) + uTime * uSwirl / (0.35 + r*0.65);
  p.xz = r * vec2(cos(a), sin(a));
  p.y += sin(uTime*0.6 + aSeed*6.2831) * 0.06 * uLift;
  vec4 mv = modelViewMatrix * vec4(p, 1.0);
  gl_PointSize = uSize * uPix * (0.5 + aSeed) * (1.0 + uBass*0.9) / max(-mv.z, 0.1);
  vSeed = aSeed;
  gl_Position = projectionMatrix * mv;
}`;

const POINTS_FRAG = /* glsl */`
uniform vec3 uColA, uColB;
uniform float uAlpha, uFade;
varying float vSeed;
void main(){
  vec2 c = gl_PointCoord - 0.5;
  float d = length(c);
  float a = smoothstep(0.5, 0.0, d);
  a *= a;
  vec3 col = mix(uColA, uColB, vSeed);
  gl_FragColor = vec4(col * a * uAlpha * uFade, 1.0);
}`;

const QUAD_VERT = /* glsl */`
varying vec2 vUv;
void main(){ vUv = uv; gl_Position = vec4(position.xy, 0.0, 1.0); }`;

const FEEDBACK_FRAG = /* glsl */`
uniform sampler2D tScene, tPrev;
uniform float uDecay, uZoom, uRot, uShift, uAspect, uKaleido;
varying vec2 vUv;
void main(){
  vec2 c = vUv - 0.5;
  c.x *= uAspect;
  c = rot2(uRot) * c * (1.0 - uZoom);
  c.x /= uAspect;
  vec2 uv = c + 0.5;
  vec3 prev = vec3(
    texture2D(tPrev, uv + vec2(uShift, 0.0)).r,
    texture2D(tPrev, uv).g,
    texture2D(tPrev, uv - vec2(uShift, 0.0)).b) * uDecay;
  if (uKaleido > 0.001) {
    // Psychedelic: trails fold back on themselves in a four-way mirror.
    vec2 k = abs(uv - 0.5);
    vec3 mirror = texture2D(tPrev, 0.5 + k * vec2(sign(vUv.x - 0.5), -sign(vUv.y - 0.5))).rgb * uDecay;
    prev = mix(prev, max(prev, mirror), uKaleido);
  }
  vec3 s = texture2D(tScene, vUv).rgb;
  gl_FragColor = vec4(max(s, prev), 1.0);
}`;

const BRIGHT_FRAG = /* glsl */`
uniform sampler2D tIn;
uniform vec2 uTexel;
uniform float uThresh;
varying vec2 vUv;
void main(){
  vec3 c = 0.25 * (
    texture2D(tIn, vUv + uTexel*vec2(-0.5,-0.5)).rgb + texture2D(tIn, vUv + uTexel*vec2(0.5,-0.5)).rgb +
    texture2D(tIn, vUv + uTexel*vec2(-0.5,0.5)).rgb + texture2D(tIn, vUv + uTexel*vec2(0.5,0.5)).rgb);
  float l = dot(c, vec3(0.2126, 0.7152, 0.0722));
  gl_FragColor = vec4(c * smoothstep(uThresh, uThresh + 0.5, l), 1.0);
}`;

const BLUR_FRAG = /* glsl */`
uniform sampler2D tIn;
uniform vec2 uDir;
varying vec2 vUv;
void main(){
  vec3 c = texture2D(tIn, vUv).rgb * 0.2270270270;
  c += texture2D(tIn, vUv + uDir*1.3846153846).rgb * 0.3162162162;
  c += texture2D(tIn, vUv - uDir*1.3846153846).rgb * 0.3162162162;
  c += texture2D(tIn, vUv + uDir*3.2307692308).rgb * 0.0702702703;
  c += texture2D(tIn, vUv - uDir*3.2307692308).rgb * 0.0702702703;
  gl_FragColor = vec4(c, 1.0);
}`;

const COMPOSITE_FRAG = /* glsl */`
uniform sampler2D tBase, tB1, tB2;
uniform float uGlow, uTime, uKick, uDarkAtmo, uPsy;
uniform vec2 uRes;
varying vec2 vUv;
vec3 aces(vec3 x){ return clamp((x*(2.51*x + 0.03)) / (x*(2.43*x + 0.59) + 0.14), 0.0, 1.0); }
float hash(vec2 p){ return fract(sin(dot(p, vec2(12.9898, 78.233))) * 43758.5453); }
vec3 hueRot(vec3 c, float a){
  const vec3 k = vec3(0.57735);
  float ca = cos(a);
  return c*ca + cross(k, c)*sin(a) + k*dot(k, c)*(1.0 - ca);
}
void main(){
  vec3 c = texture2D(tBase, vUv).rgb;
  vec3 b = texture2D(tB1, vUv).rgb*0.6 + texture2D(tB2, vUv).rgb*0.9;
  c += b * uGlow * (1.0 + 0.35*uKick) * (1.0 - 0.35*uDarkAtmo);
  float l = dot(c, vec3(0.2126, 0.7152, 0.0722));
  // Dark: drained colour, crushed shadows, blood-red highlights.
  vec3 dk = mix(vec3(l), c, 0.22);
  dk = pow(max(dk, 0.0), vec3(1.45)) * 0.8;
  dk *= mix(vec3(0.85, 0.8, 0.9), vec3(1.6, 0.32, 0.38), smoothstep(0.08, 0.7, l));
  c = mix(c, dk, uDarkAtmo);
  // Psychedelic: hues sweep across the screen and through brightness, colour pushed hard.
  vec3 ps = hueRot(c, uTime*0.4 + length(vUv - 0.5)*7.0 + l*4.0 + uKick*0.8);
  float pl = dot(ps, vec3(0.2126, 0.7152, 0.0722));
  ps = max(mix(vec3(pl), ps, 1.7), 0.0);
  c = mix(c, ps, uPsy);
  vec2 q = (vUv - 0.5) * vec2(1.0, 0.85);
  c *= mix(1.0, smoothstep(0.95, 0.2, length(q)), 0.7 + 0.25*uDarkAtmo);
  c = aces(c * 1.05);
  c = pow(c, vec3(1.0/2.2));
  c += (hash(vUv*uRes + fract(uTime)*91.7) - 0.5) * 0.03;
  gl_FragColor = vec4(c, 1.0);
}`;

// ---------- Engine ----------
const MODE_AMP = { orb: 1.0, fractal: 0.85, ribbon: 0.42, void: 0.55 };
const lerp = (a, b, t) => a + (b - a) * t;

function makePoints(count, gen, uniforms) {
  const pos = new Float32Array(count * 3);
  const seed = new Float32Array(count);
  for (let i = 0; i < count; i++) {
    const [x, y, z, s] = gen(i);
    pos[i * 3] = x; pos[i * 3 + 1] = y; pos[i * 3 + 2] = z; seed[i] = s;
  }
  const g = new THREE.BufferGeometry();
  g.setAttribute('position', new THREE.BufferAttribute(pos, 3));
  g.setAttribute('aSeed', new THREE.BufferAttribute(seed, 1));
  const m = new THREE.ShaderMaterial({
    vertexShader: POINTS_VERT, fragmentShader: POINTS_FRAG, uniforms,
    transparent: true, depthWrite: false, blending: THREE.AdditiveBlending,
  });
  const p = new THREE.Points(g, m);
  p.frustumCulled = false;
  return p;
}

export class Engine {
  constructor(canvas, { mobile = false, reducedMotion = false, onError } = {}) {
    this.canvas = canvas;
    this.mobile = mobile;
    this.reducedMotion = reducedMotion;
    this.onError = onError || (() => {});
    this.disposables = [];
    this.thumbRequests = [];

    const renderer = new THREE.WebGLRenderer({ canvas, antialias: false, alpha: false, powerPreference: 'high-performance', preserveDrawingBuffer: false });
    if (!renderer.capabilities.isWebGL2) throw new Error('WebGL2 is required');
    renderer.outputColorSpace = THREE.LinearSRGBColorSpace;
    renderer.autoClear = true;
    renderer.debug.onShaderError = (gl, program, vs, fs) => {
      const log = gl.getShaderInfoLog(vs) || gl.getShaderInfoLog(fs) || gl.getProgramInfoLog(program);
      this.onError('shader', log);
    };
    this.renderer = renderer;
    this.maxDpr = Math.min(window.devicePixelRatio || 1, mobile ? 1.5 : 1.75);
    this.dpr = this.maxDpr;

    // Scene
    this.scene = new THREE.Scene();
    this.camera = new THREE.PerspectiveCamera(38, 1, 0.05, 100);
    this.camera.position.set(0, 0, 4.6);

    const col = () => new THREE.Color();
    this.u = {
      uTime: { value: 0 }, uBass: { value: 0 }, uMidE: { value: 0 }, uTreble: { value: 0 }, uKick: { value: 0 },
      uDeform: { value: 0.5 }, uFreq: { value: 1.4 }, uSharp: { value: 0 }, uWarp: { value: 0 }, uFlow: { value: 0 },
      uDetail: { value: 0.5 }, uAmp: { value: 1 }, uFade: { value: 0 }, uFlat: { value: 0 }, uDark: { value: 0 },
      uColBase: { value: col() }, uColMid: { value: col() }, uColAcc: { value: col() }, uColRim: { value: col() },
    };
    this.sculptMat = new THREE.ShaderMaterial({ vertexShader: SCULPT_VERT, fragmentShader: SCULPT_FRAG, uniforms: this.u });
    this.sculpt = new THREE.Mesh(new THREE.BufferGeometry(), this.sculptMat);
    this.sculpt.frustumCulled = false;
    this.pivot = new THREE.Group();
    this.pivot.add(this.sculpt);
    this.scene.add(this.pivot);

    // Fractal shards
    this.shardU = {
      uTime: this.u.uTime, uTreble: this.u.uTreble, uKick: this.u.uKick, uFade: this.u.uFade,
      uColMid: this.u.uColMid, uColAcc: this.u.uColAcc, uColRim: this.u.uColRim, uShow: { value: 0 },
    };
    this.shardMat = new THREE.ShaderMaterial({ vertexShader: SHARD_VERT, fragmentShader: SHARD_FRAG, uniforms: this.shardU });
    this.shards = new THREE.InstancedMesh(new THREE.OctahedronGeometry(0.07, 0), this.shardMat, 72);
    this.shards.frustumCulled = false;
    this.scene.add(this.shards);

    // Dust field (all modes)
    this.pix = { value: 1 };
    this.dustU = {
      uTime: this.u.uTime, uBass: this.u.uBass, uSize: { value: 14 }, uSwirl: { value: 0.02 }, uPix: this.pix, uLift: { value: 1 },
      uColA: { value: col() }, uColB: { value: col() }, uAlpha: { value: 0.35 }, uFade: { value: 1 },
    };
    const drng = mulberry32(7);
    this.dust = makePoints(mobile ? 700 : 1500, () => {
      const r = 5 + drng() * 14, th = drng() * Math.PI * 2, ph = Math.acos(2 * drng() - 1);
      return [r * Math.sin(ph) * Math.cos(th), r * Math.cos(ph) * 0.6, r * Math.sin(ph) * Math.sin(th), drng()];
    }, this.dustU);
    this.scene.add(this.dust);

    // Accretion disk (void)
    this.diskU = {
      uTime: this.u.uTime, uBass: this.u.uBass, uSize: { value: 7 }, uSwirl: { value: 0.35 }, uPix: this.pix, uLift: { value: 0.6 },
      uColA: { value: col() }, uColB: { value: col() }, uAlpha: { value: 0 }, uFade: this.u.uFade,
    };
    const krng = mulberry32(11);
    this.disk = makePoints(mobile ? 3000 : 7000, () => {
      const r = 0.85 + Math.pow(krng(), 1.8) * 1.9, a = krng() * Math.PI * 2;
      return [Math.cos(a) * r, (krng() - 0.5) * 0.05 * r, Math.sin(a) * r, krng()];
    }, this.diskU);
    this.disk.rotation.x = 0.42;
    this.scene.add(this.disk);

    // Everything that floats: lifted into the sky when a landscape appears.
    this.cluster = new THREE.Group();
    this.cluster.add(this.pivot, this.shards, this.disk);
    this.scene.add(this.cluster);

    this.land = new Landscapes(this.scene, {
      uTime: this.u.uTime, uBass: this.u.uBass, uMidE: this.u.uMidE, uTreble: this.u.uTreble, uKick: this.u.uKick,
      uColBase: this.u.uColBase, uColMid: this.u.uColMid, uColAcc: this.u.uColAcc, uColRim: this.u.uColRim, uPix: this.pix,
    }, { mobile });
    this.spec = null;
    this.specMix = new Float32Array(64);
    this.envMix = 0;
    this.atmo = 'natural';
    this.moon = new THREE.Vector3();

    this.disposables.push(this.sculptMat, this.shardMat, this.shards.geometry, this.dust.geometry, this.dust.material, this.disk.geometry, this.disk.material);

    // Post-processing
    this.quadCam = new THREE.OrthographicCamera(-1, 1, 1, -1, 0, 1);
    this.quadScene = new THREE.Scene();
    this.quad = new THREE.Mesh(new THREE.PlaneGeometry(2, 2));
    this.quad.frustumCulled = false;
    this.quadScene.add(this.quad);
    const qm = (frag, uniforms) => {
      const m = new THREE.ShaderMaterial({ vertexShader: QUAD_VERT, fragmentShader: (frag.includes('rot2') ? NOISE : '') + frag, uniforms, depthTest: false, depthWrite: false });
      this.disposables.push(m);
      return m;
    };
    this.feedbackMat = qm(FEEDBACK_FRAG, { tScene: { value: null }, tPrev: { value: null }, uDecay: { value: 0 }, uZoom: { value: 0 }, uRot: { value: 0 }, uShift: { value: 0 }, uAspect: { value: 1 }, uKaleido: { value: 0 } });
    this.brightMat = qm(BRIGHT_FRAG, { tIn: { value: null }, uTexel: { value: new THREE.Vector2() }, uThresh: { value: 0.55 } });
    this.blurMat = qm(BLUR_FRAG, { tIn: { value: null }, uDir: { value: new THREE.Vector2() } });
    this.compMat = qm(COMPOSITE_FRAG, { tBase: { value: null }, tB1: { value: null }, tB2: { value: null }, uGlow: { value: 0.5 }, uTime: this.u.uTime, uKick: this.u.uKick, uRes: { value: new THREE.Vector2() }, uDarkAtmo: { value: 0 }, uPsy: { value: 0 } });
    this.disposables.push(this.quad.geometry);
    this.targets = null;

    // State
    this.cur = null;         // interpolated params
    this.tgt = null;         // target config
    this.mode = null;        // geometry currently built
    this.pendingMode = null;
    this.geomKey = '';
    this.palCur = null;
    this.features = { bass: 0, mid: 0, treble: 0, loud: 0, kick: 0, active: false };
    this.live = { bass: 0, mid: 0, treble: 0, kick: 0 };
    this.activeMix = 0;
    this.time = 0;
    this.clockPrev = performance.now();
    this.camAngle = 0;
    this.pointer = { x: 0, y: 0, tx: 0, ty: 0 };
    this.frameTimes = [];
    this.lastDprDrop = 0;
    this.running = false;
    this.lost = false;

    this._onResize = () => this.resize();
    this._onPointer = (e) => {
      this.pointer.tx = (e.clientX / window.innerWidth) * 2 - 1;
      this.pointer.ty = (e.clientY / window.innerHeight) * 2 - 1;
    };
    window.addEventListener('resize', this._onResize);
    window.addEventListener('pointermove', this._onPointer, { passive: true });
    this._onLost = (e) => { e.preventDefault(); this.lost = true; this.onError('lost'); };
    canvas.addEventListener('webglcontextlost', this._onLost);
    this.resize();
  }

  // ----- sizing -----
  resize() {
    const w = Math.max(1, window.innerWidth), h = Math.max(1, window.innerHeight);
    this.renderer.setPixelRatio(this.dpr);
    this.renderer.setSize(w, h, false);
    this.camera.aspect = w / h;
    this.camera.fov = w / h < 0.8 ? 52 : 38; // portrait phones need a wider lens
    this.camera.updateProjectionMatrix();
    const W = Math.floor(w * this.dpr), H = Math.floor(h * this.dpr);
    this.pix.value = H / 900;
    if (this.targets) Object.values(this.targets).forEach((t) => t.dispose());
    const opts = { type: THREE.HalfFloatType, depthBuffer: false, minFilter: THREE.LinearFilter, magFilter: THREE.LinearFilter };
    this.targets = {
      scene: new THREE.WebGLRenderTarget(W, H, { ...opts, depthBuffer: true }),
      fbA: new THREE.WebGLRenderTarget(W, H, opts),
      fbB: new THREE.WebGLRenderTarget(W, H, opts),
      h1: new THREE.WebGLRenderTarget(W >> 1, H >> 1, opts),
      h2: new THREE.WebGLRenderTarget(W >> 1, H >> 1, opts),
      q1: new THREE.WebGLRenderTarget(W >> 2, H >> 2, opts),
      q2: new THREE.WebGLRenderTarget(W >> 2, H >> 2, opts),
    };
    this.feedbackMat.uniforms.uAspect.value = w / h;
    this.compMat.uniforms.uRes.value.set(W, H);
    this.size = { W, H };
  }

  // ----- geometry -----
  buildGeometry(cfg) {
    const det = this.mobile ? Math.min(cfg.detail, 0.6) : cfg.detail;
    let geom, key;
    if (cfg.mode === 'orb' || cfg.mode === 'void') {
      const lvl = Math.round(det * 4);
      const ws = 96 + lvl * 40, hs = Math.round(ws * 0.66);
      key = `${cfg.mode}:${ws}`;
      if (key === this.geomKey) return;
      geom = new THREE.SphereGeometry(cfg.mode === 'void' ? 0.62 : 1, ws, hs);
    } else if (cfg.mode === 'fractal') {
      const lv = Math.round(6 + Math.round(det * 4) * 2.5);
      key = `fractal:${lv}`;
      if (key === this.geomKey) return;
      geom = new THREE.IcosahedronGeometry(0.95, lv);
    } else {
      const [p, q] = knotFor(cfg.seed);
      const lvl = Math.round(det * 4);
      const ts = 220 + lvl * 95, rs = 18 + lvl * 8;
      key = `ribbon:${p}:${q}:${ts}`;
      if (key === this.geomKey) return;
      geom = new THREE.TorusKnotGeometry(0.62, 0.17, ts, rs, p, q);
    }
    this.sculpt.geometry.dispose();
    this.sculpt.geometry = geom;
    this.geomKey = key;
    this.mode = cfg.mode;
    this.layoutShards(cfg.seed);
  }

  layoutShards(seed) {
    const rng = mulberry32(hashString(seed + ':shards'));
    const m = new THREE.Matrix4(), q = new THREE.Quaternion(), s = new THREE.Vector3(), p = new THREE.Vector3(), e = new THREE.Euler();
    for (let i = 0; i < this.shards.count; i++) {
      const r = 1.55 + rng() * 1.1, a = rng() * Math.PI * 2, y = (rng() - 0.5) * 1.6;
      p.set(Math.cos(a) * r, y, Math.sin(a) * r);
      e.set(rng() * 6, rng() * 6, rng() * 6);
      q.setFromEuler(e);
      const k = 0.4 + Math.pow(rng(), 3) * 2.2;
      s.set(k * 0.6, k * (1.5 + rng() * 2.5), k * 0.6);
      m.compose(p, q, s);
      this.shards.setMatrixAt(i, m);
    }
    this.shards.instanceMatrix.needsUpdate = true;
  }

  // ----- config -----
  setConfig(cfg) {
    this.tgt = { ...cfg };
    if (!this.cur) {
      this.cur = { ...cfg };
      this.buildGeometry(cfg);
      this.applyPalette(cfg.palette, 1);
      return;
    }
    if (cfg.mode !== this.mode || (cfg.mode === 'ribbon' && !this.geomKey.startsWith(`ribbon:${knotFor(cfg.seed).join(':')}:`))) {
      this.pendingMode = true; // fade out, rebuild, fade in
    } else {
      this.buildGeometry(cfg); // detail change within a mode
    }
    if (cfg.mode === 'fractal' && this.mode === 'fractal') this.layoutShards(cfg.seed);
  }

  applyPalette(name, t) {
    const P = PALETTE_DEFS[name] || PALETTE_DEFS.mono;
    const c = new THREE.Color();
    const set = (u, hex) => u.value.lerp(c.setHex(hex), t);
    set(this.u.uColBase, P.base); set(this.u.uColMid, P.mid); set(this.u.uColAcc, P.acc); set(this.u.uColRim, P.rim);
    set(this.dustU.uColA, P.dustA); set(this.dustU.uColB, P.dustB);
    set(this.diskU.uColA, P.dustA); set(this.diskU.uColB, P.dustB);
    if (!this.bg) this.bg = new THREE.Color(P.bg);
    this.bg.lerp(c.setHex(P.bg), t);
  }

  setFeatures(f) { this.features = f; }

  setSpectrum(arr) { this.spec = arr; }

  setEnvironment(name) { this.land.setTarget(name); }

  setAtmosphere(name) { this.atmo = name; }

  requestThumb(cb) { this.thumbRequests.push(cb); }

  // ----- loop -----
  start() {
    if (this.running) return;
    this.running = true;
    this.clockPrev = performance.now();
    const loop = () => {
      if (!this.running) return;
      this.raf = requestAnimationFrame(loop);
      try { this.frame(); } catch (err) { this.running = false; this.onError('frame', err && err.message); }
    };
    this.raf = requestAnimationFrame(loop);
  }

  stop() { this.running = false; cancelAnimationFrame(this.raf); }

  frame() {
    if (this.lost || !this.cur) return;
    const now = performance.now();
    const dt = Math.min(0.05, (now - this.clockPrev) / 1000);
    this.clockPrev = now;
    this.trackPerformance(dt * 1000, now);

    const c = this.cur, g = this.tgt;
    const k = 1 - Math.exp(-dt * 3.5);
    for (const key of ['deform', 'motion', 'detail', 'glow', 'trail', 'freq', 'sharp', 'warp', 'flow', 'scale']) {
      c[key] = lerp(c[key], g[key], k);
    }
    this.applyPalette(g.palette, k);

    // Mode transitions via fade
    const fadeTarget = this.pendingMode ? 0 : 1;
    this.u.uFade.value = lerp(this.u.uFade.value, fadeTarget, 1 - Math.exp(-dt * (this.pendingMode ? 9 : 4)));
    if (this.pendingMode && this.u.uFade.value < 0.04) {
      this.pendingMode = false;
      this.buildGeometry(g);
    }

    // Audio features — blend live analysis with an idle "dream" so the piece never sits still.
    const f = this.features;
    this.activeMix = lerp(this.activeMix, f.active ? 1 : 0, 1 - Math.exp(-dt * 2));
    const t = this.time;
    const idle = {
      bass: 0.32 + 0.22 * Math.sin(t * 0.8) + 0.1 * Math.sin(t * 2.1),
      mid: 0.28 + 0.15 * Math.sin(t * 1.3 + 1),
      treble: 0.16 + 0.1 * Math.sin(t * 3.7 + 2),
      kick: Math.pow(Math.max(0, Math.sin(t * 2.6)), 24) * 0.55,
    };
    const am = this.activeMix;
    const L = this.live;
    L.bass = lerp(idle.bass, f.bass, am);
    L.mid = lerp(idle.mid, f.mid, am);
    L.treble = lerp(idle.treble, f.treble, am);
    L.kick = lerp(idle.kick, f.kick, am);

    const cm = this.compMat.uniforms;
    const ga = 1 - Math.exp(-dt * 1.5);
    cm.uDarkAtmo.value = lerp(cm.uDarkAtmo.value, this.atmo === 'dark' ? 1 : 0, ga);
    cm.uPsy.value = lerp(cm.uPsy.value, this.atmo === 'psychedelic' ? (this.reducedMotion ? 0.5 : 1) : 0, ga);
    this.feedbackMat.uniforms.uKaleido.value = this.reducedMotion ? 0 : cm.uPsy.value * 0.55;
    const motionScale = (this.reducedMotion ? 0.35 : 1) * (1 - 0.3 * cm.uDarkAtmo.value) * (1 + 0.25 * cm.uPsy.value);
    const speed = (0.25 + c.motion * 1.1) * motionScale * (1 + (f.loud || 0) * 0.6 * am);
    this.time += dt * speed;

    const u = this.u;
    u.uTime.value = this.time;
    u.uBass.value = L.bass; u.uMidE.value = L.mid; u.uTreble.value = L.treble; u.uKick.value = L.kick;
    u.uDeform.value = c.deform; u.uFreq.value = c.freq; u.uSharp.value = c.sharp; u.uWarp.value = c.warp;
    u.uFlow.value = c.flow; u.uDetail.value = c.detail;
    const mode = this.mode;
    u.uAmp.value = MODE_AMP[mode] || 1;
    u.uFlat.value = mode === 'fractal' ? 1 : c.sharp * 0.3;
    u.uDark.value = mode === 'void' ? 0.88 : 0;
    this.shardU.uShow.value = lerp(this.shardU.uShow.value, mode === 'fractal' ? 1 : 0, 1 - Math.exp(-dt * 3));
    this.shards.visible = this.shardU.uShow.value > 0.01;
    this.diskU.uAlpha.value = lerp(this.diskU.uAlpha.value, mode === 'void' ? 0.9 : 0, 1 - Math.exp(-dt * 3));
    this.disk.visible = this.diskU.uAlpha.value > 0.01;
    this.diskU.uSwirl.value = 0.25 + c.motion * 0.5 + L.bass * 0.3;

    // Spectrum for landscapes: live bands, or a slow synthetic one while idle.
    const SM = this.specMix;
    for (let i = 0; i < 64; i++) {
      const x = i / 64;
      const idleV = Math.max(0, (0.3 + 0.22 * Math.sin(t * 0.9 + i * 0.35) + 0.12 * Math.sin(t * 2.3 - i * 0.8)) * (1 - x * 0.55) + idle.kick * (1 - x) * 0.6);
      const liveV = this.spec ? this.spec[i] : 0;
      SM[i] = idleV + (liveV - idleV) * am;
    }
    this.moon.set(0, this.cluster.position.y, 0);
    const envMix = this.land.update(dt, SM, L, this.bg, this.moon);
    this.envMix = envMix;
    const em = envMix * envMix * (3 - 2 * envMix);
    this.cluster.position.y = 1.45 * em;
    this.cluster.scale.setScalar(1 - 0.45 * em);

    // Object motion
    const rotSpeed = (0.06 + c.motion * 0.28) * motionScale * (1 + L.bass * 0.6);
    this.pivot.rotation.y += dt * rotSpeed;
    this.pivot.rotation.x = Math.sin(this.time * 0.21) * (mode === 'ribbon' ? 0.6 : 0.18);
    this.pivot.rotation.z = mode === 'ribbon' ? this.time * 0.07 : Math.sin(this.time * 0.13) * 0.1;
    const s = c.scale * (1 + L.kick * 0.04);
    this.pivot.scale.setScalar(s);
    this.shards.rotation.y -= dt * rotSpeed * 0.6;
    this.shards.rotation.x = Math.sin(this.time * 0.17) * 0.25;
    this.shards.scale.setScalar(c.scale);
    this.disk.scale.setScalar(c.scale);
    this.dust.rotation.y += dt * 0.01;

    // Camera
    const p = this.pointer;
    p.x = lerp(p.x, p.tx, 1 - Math.exp(-dt * 2));
    p.y = lerp(p.y, p.ty, 1 - Math.exp(-dt * 2));
    this.camAngle += dt * (0.04 + 0.05 * this.envMix) * c.motion * motionScale;
    const portrait = this.camera.aspect < 0.8 ? 1.45 : 1;
    const spaceRadius = ((mode === 'void' ? 6.0 : 5.3) - L.kick * 0.2 * motionScale) * portrait;
    const landRadius = 7.4 - L.kick * 0.12 * motionScale;
    const radius = spaceRadius + (landRadius - spaceRadius) * em;
    const spaceElev = 0.12 + Math.sin(this.time * 0.11) * 0.12 + p.y * 0.18 + (mode === 'void' ? 0.1 : 0);
    const landElev = 0.1 + Math.sin(this.time * 0.11) * 0.04 + p.y * 0.07;
    const elev = spaceElev + (landElev - spaceElev) * em;
    const az = this.camAngle + p.x * 0.3;
    this.camera.position.set(Math.sin(az) * Math.cos(elev) * radius, Math.sin(elev) * radius, Math.cos(az) * Math.cos(elev) * radius);
    this.camera.lookAt(0, 0.55 * em, 0);

    this.render(c, L, dt);
  }

  render(c, L, dt = 1 / 60) {
    const r = this.renderer, T = this.targets;
    r.setClearColor(this.bg, 1);
    r.setRenderTarget(T.scene);
    r.render(this.scene, this.camera);

    // Feedback: the afterimage. Previous frame decays, drifts and splits colour.
    const fm = this.feedbackMat.uniforms;
    fm.tScene.value = T.scene.texture;
    fm.tPrev.value = T.fbB.texture;
    const fr = dt * 60; // frame-rate independent trails
    const trail = c.trail * (1 - 0.6 * this.envMix); // landscapes stay crisp
    fm.uDecay.value = trail < 0.02 ? 0 : Math.pow(0.78 + trail * 0.17, fr);
    const drift = this.reducedMotion ? 0 : fr;
    fm.uZoom.value = drift * (0.0006 + L.bass * 0.0018 + L.kick * 0.0035) * (0.3 + c.trail);
    fm.uRot.value = drift * (c.warp - 0.3) * 0.0025 * (1 + L.mid);
    fm.uShift.value = drift * (0.00025 + L.treble * 0.0006);
    this.pass(this.feedbackMat, T.fbA);
    [T.fbA, T.fbB] = [T.fbB, T.fbA]; // fbB now holds this frame

    // Bloom
    const bm = this.brightMat.uniforms;
    bm.tIn.value = T.fbB.texture;
    bm.uTexel.value.set(1 / this.size.W, 1 / this.size.H);
    bm.uThresh.value = 0.45;
    this.pass(this.brightMat, T.h1);
    this.blur(T.h1, T.h2, this.size.W >> 1, this.size.H >> 1);
    this.blurMat.uniforms.tIn.value = T.h1.texture;
    this.blurMat.uniforms.uDir.value.set(0, 0);
    this.pass(this.blurMat, T.q1); // downsample
    this.blur(T.q1, T.q2, this.size.W >> 2, this.size.H >> 2);

    const cm = this.compMat.uniforms;
    cm.tBase.value = T.fbB.texture;
    cm.tB1.value = T.h1.texture;
    cm.tB2.value = T.q1.texture;
    cm.uGlow.value = c.glow * 1.5;
    this.pass(this.compMat, null);

    if (this.thumbRequests.length) {
      const cbs = this.thumbRequests.splice(0);
      try {
        const tc = document.createElement('canvas');
        tc.width = 96; tc.height = 96;
        const ctx = tc.getContext('2d');
        const src = this.canvas, side = Math.min(src.width, src.height) * 0.7;
        ctx.drawImage(src, (src.width - side) / 2, (src.height - side) / 2, side, side, 0, 0, 96, 96);
        const url = tc.toDataURL('image/jpeg', 0.7);
        cbs.forEach((cb) => cb(url));
      } catch { cbs.forEach((cb) => cb(null)); }
    }
  }

  blur(a, b, w, h) {
    const m = this.blurMat.uniforms;
    for (let i = 0; i < 2; i++) {
      m.tIn.value = a.texture; m.uDir.value.set((1 + i) / w, 0); this.pass(this.blurMat, b);
      m.tIn.value = b.texture; m.uDir.value.set(0, (1 + i) / h); this.pass(this.blurMat, a);
    }
  }

  pass(material, target) {
    this.quad.material = material;
    this.renderer.setRenderTarget(target);
    this.renderer.render(this.quadScene, this.quadCam);
  }

  trackPerformance(ms, now) {
    const ft = this.frameTimes;
    ft.push(ms);
    if (ft.length > 90) ft.shift();
    if (ft.length < 90 || now - this.lastDprDrop < 3000 || document.hidden) return;
    const avg = ft.reduce((a, b) => a + b, 0) / ft.length;
    if (avg > 24 && this.dpr > 0.75) {
      this.dpr = Math.max(0.75, this.dpr * 0.82);
      this.lastDprDrop = now;
      ft.length = 0;
      this.resize();
    }
  }

  dispose() {
    this.stop();
    window.removeEventListener('resize', this._onResize);
    window.removeEventListener('pointermove', this._onPointer);
    this.canvas.removeEventListener('webglcontextlost', this._onLost);
    this.sculpt.geometry.dispose();
    this.disposables.forEach((d) => d.dispose());
    if (this.targets) Object.values(this.targets).forEach((t) => t.dispose());
    this.shards.dispose();
    this.land.dispose();
    this.renderer.dispose();
  }
}
