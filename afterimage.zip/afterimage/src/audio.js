// AFTERIMAGE audio — sources (file / tab / mic), feature extraction and mood reading.
import { MoodTracker, classifyAtmosphere } from './core.js';
import { flatness } from './scan.js';

export const SPEC_BINS = 64;

export class AudioEngine {
  constructor(el) {
    this.el = el;
    this.ctx = null;
    this.analyser = null;
    this.elSource = null;
    this.streamSource = null;
    this.stream = null;
    this.recDest = null;
    this.source = 'none'; // 'none' | 'file' | 'tab' | 'mic'
    this.onStreamEnded = null;
    this.features = { bass: 0, mid: 0, treble: 0, loud: 0, kick: 0, active: false, time: 0 };
    this.peaks = { bass: 0.2, mid: 0.2, treble: 0.2 };
    this.fluxAvg = 0;
    this.sinceOnset = 1;
    this.spec = new Float32Array(SPEC_BINS); // log-spaced spectrum, 0..1, for landscapes
    this.specPeak = 0.3;
    this.mood = new MoodTracker();
    this.atmo = new MoodTracker({ pick: classifyAtmosphere, warmup: 12, confirm: 8, dwell: 25 });
    this.stats = { e: 0.4, b: 0.4, o: 0.3, w: 0.5 };
    this.atmoStats = { e: 0.4, b: 0.4, flat: 0.12, vari: 0.2, long: 0 };
    this.history = { b: [], e: [], acc: { b: 0, e: 0, n: 0, t: 0 } };
    this.onsetTimes = [];
    this.clock = 0;
  }

  resetMood() {
    this.mood.reset();
    this.atmo.reset();
    this.atmoStats = { e: 0.4, b: 0.4, flat: 0.12, vari: 0.2, long: 0 };
    this.history = { b: [], e: [], acc: { b: 0, e: 0, n: 0, t: 0 } };
    this.onsetTimes = [];
    this.stats = { e: 0.4, b: 0.4, o: 0.3, w: 0.5 };
  }

  /** Create or resume the AudioContext. Must be called from a user gesture. */
  ensure() {
    if (!this.ctx) {
      const AC = window.AudioContext || window.webkitAudioContext;
      if (!AC) throw new Error('Web Audio is not supported in this browser.');
      this.ctx = new AC();
      this.analyser = this.ctx.createAnalyser();
      this.analyser.fftSize = 2048;
      this.analyser.smoothingTimeConstant = 0.55;
      this.freq = new Uint8Array(this.analyser.frequencyBinCount);
      this.prevSpec = new Float32Array(this.analyser.frequencyBinCount);
      this.timeData = new Uint8Array(this.analyser.fftSize);
    }
    if (this.ctx.state === 'suspended') this.ctx.resume().catch(() => {});
    return this.ctx;
  }

  useElement() {
    this.ensure();
    this.stopStream();
    if (!this.elSource) this.elSource = this.ctx.createMediaElementSource(this.el);
    try { this.elSource.disconnect(); } catch {}
    try { this.analyser.disconnect(); } catch {}
    this.elSource.connect(this.analyser);
    this.analyser.connect(this.ctx.destination);
    this.resetMood();
    if (this.recDest) this.elSource.connect(this.recDest);
    this.source = 'file';
  }

  async useTab() {
    this.ensure();
    if (!navigator.mediaDevices || !navigator.mediaDevices.getDisplayMedia) {
      throw Object.assign(new Error('unsupported'), { code: 'unsupported' });
    }
    const stream = await navigator.mediaDevices.getDisplayMedia({
      video: true,
      audio: { echoCancellation: false, noiseSuppression: false, autoGainControl: false },
      systemAudio: 'include',
      selfBrowserSurface: 'exclude',
      surfaceSwitching: 'include',
    });
    if (!stream.getAudioTracks().length) {
      stream.getTracks().forEach((t) => t.stop());
      throw Object.assign(new Error('noaudio'), { code: 'noaudio' });
    }
    this.attachStream(stream, 'tab');
  }

  async useMic() {
    this.ensure();
    if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
      throw Object.assign(new Error('unsupported'), { code: 'unsupported' });
    }
    const stream = await navigator.mediaDevices.getUserMedia({
      audio: { echoCancellation: false, noiseSuppression: false, autoGainControl: false },
    });
    this.attachStream(stream, 'mic');
  }

  attachStream(stream, kind) {
    this.stopStream();
    this.el.pause();
    if (this.elSource) { try { this.elSource.disconnect(); } catch {} }
    try { this.analyser.disconnect(); } catch {} // never route a captured stream to the speakers (echo)
    this.streamSource = this.ctx.createMediaStreamSource(stream);
    this.streamSource.connect(this.analyser);
    this.stream = stream;
    this.source = kind;
    this.resetMood();
    const ended = () => {
      if (this.stream !== stream) return;
      this.stopStream();
      this.source = 'none';
      if (this.onStreamEnded) this.onStreamEnded(kind);
    };
    stream.getTracks().forEach((t) => t.addEventListener('ended', ended));
  }

  stopStream() {
    if (this.stream) this.stream.getTracks().forEach((t) => t.stop());
    if (this.streamSource) { try { this.streamSource.disconnect(); } catch {} }
    this.stream = null;
    this.streamSource = null;
    if (this.source === 'tab' || this.source === 'mic') this.source = 'none';
  }

  /** Audio track for clip recording, or null. */
  recordingTrack() {
    if (!this.ctx) return null;
    if (this.stream && this.stream.getAudioTracks()[0]) return this.stream.getAudioTracks()[0].clone();
    if (this.source === 'file' && this.elSource) {
      if (!this.recDest) {
        this.recDest = this.ctx.createMediaStreamDestination();
        this.elSource.connect(this.recDest);
      }
      return this.recDest.stream.getAudioTracks()[0];
    }
    return null;
  }

  get isActive() {
    if (!this.analyser) return false;
    if (this.source === 'file') return !this.el.paused && !this.el.ended;
    return this.source === 'tab' || this.source === 'mic';
  }

  /** Update normalized features. Call once per animation frame. */
  update(dt) {
    const f = this.features;
    const smooth = (key, target, attack, release) => {
      const rate = target > f[key] ? attack : release;
      f[key] += (target - f[key]) * (1 - Math.exp(-dt * rate));
    };
    f.kick *= Math.exp(-dt * 6);
    f.time = this.el.currentTime || 0;

    this.clock += dt;
    if (!this.isActive) {
      f.active = false;
      for (const k of ['bass', 'mid', 'treble', 'loud']) smooth(k, 0, 10, 3);
      const k = Math.exp(-dt * 3);
      for (let i = 0; i < SPEC_BINS; i++) this.spec[i] *= k;
      return f;
    }
    f.active = true;

    const a = this.analyser;
    a.getByteFrequencyData(this.freq);
    a.getByteTimeDomainData(this.timeData);
    const binHz = this.ctx.sampleRate / a.fftSize;
    const n = this.freq.length;
    const band = (lo, hi) => {
      const i0 = Math.max(1, Math.floor(lo / binHz)), i1 = Math.min(n - 1, Math.ceil(hi / binHz));
      let s = 0;
      for (let i = i0; i <= i1; i++) s += this.freq[i];
      return s / ((i1 - i0 + 1) * 255);
    };
    const raw = { bass: band(30, 160), mid: band(300, 2000), treble: band(4000, 12000) };

    // Adaptive per-band peak so quiet and loud songs both use the full range.
    const decay = Math.exp(-dt * 0.22);
    for (const k of ['bass', 'mid', 'treble']) {
      this.peaks[k] = Math.max(raw[k], this.peaks[k] * decay, 0.06);
      const norm = raw[k] < 0.015 ? 0 : raw[k] / this.peaks[k];
      // Emphasise movement near the top of the range rather than the steady floor.
      const shaped = Math.min(1, Math.max(0, (norm - 0.3) / 0.7));
      smooth(k, shaped * shaped * (3 - 2 * shaped), 22, 5);
    }

    // RMS loudness
    let sum = 0;
    for (let i = 0; i < this.timeData.length; i++) {
      const v = (this.timeData[i] - 128) / 128;
      sum += v * v;
    }
    smooth('loud', Math.min(1, Math.sqrt(sum / this.timeData.length) * 3.2), 15, 3);

    // Onset detection: positive spectral flux below ~2.5 kHz against a moving average.
    const top = Math.min(n, Math.ceil(2500 / binHz));
    let flux = 0;
    for (let i = 1; i < top; i++) {
      const v = this.freq[i] / 255;
      const d = v - this.prevSpec[i];
      if (d > 0) flux += d;
      this.prevSpec[i] = v;
    }
    flux /= top;
    this.fluxAvg += (flux - this.fluxAvg) * (1 - Math.exp(-dt * 2.5));
    this.sinceOnset += dt;
    if (flux > this.fluxAvg * 1.55 + 0.006 && this.sinceOnset > 0.11) {
      const strength = Math.min(1, (flux / (this.fluxAvg + 1e-4) - 1) * 0.6);
      f.kick = Math.max(f.kick, 0.35 + strength * 0.65);
      this.sinceOnset = 0;
      this.onsetTimes.push(this.clock);
    }

    this.updateSpectrum(dt, binHz, n);
    this.updateMood(dt, raw, binHz, n);
    return f;
  }

  // 64 log-spaced bands from 40 Hz to 14 kHz with an adaptive ceiling.
  updateSpectrum(dt, binHz, n) {
    const lo = Math.log(40), hi = Math.log(14000);
    let maxV = 0;
    const tmp = this._tmp || (this._tmp = new Float32Array(SPEC_BINS));
    for (let b = 0; b < SPEC_BINS; b++) {
      const f0 = Math.exp(lo + (hi - lo) * (b / SPEC_BINS)), f1 = Math.exp(lo + (hi - lo) * ((b + 1) / SPEC_BINS));
      const i0 = Math.max(1, Math.floor(f0 / binHz)), i1 = Math.min(n - 1, Math.max(i0, Math.ceil(f1 / binHz)));
      let s = 0;
      for (let i = i0; i <= i1; i++) s += this.freq[i];
      tmp[b] = s / ((i1 - i0 + 1) * 255);
      if (tmp[b] > maxV) maxV = tmp[b];
    }
    this.specPeak = Math.max(maxV, this.specPeak * Math.exp(-dt * 0.3), 0.08);
    for (let b = 0; b < SPEC_BINS; b++) {
      const v = Math.max(0, (tmp[b] / this.specPeak - 0.2) / 0.8);
      const rate = v > this.spec[b] ? 20 : 5;
      this.spec[b] += (v - this.spec[b]) * (1 - Math.exp(-dt * rate));
    }
  }

  // Slow statistics that describe the character of the song, not the moment.
  updateMood(dt, raw, binHz, n) {
    let num = 0, den = 0;
    const top = Math.min(n, Math.ceil(11000 / binHz));
    for (let i = 1; i < top; i++) { num += i * this.freq[i]; den += this.freq[i]; }
    const centroid = den > 0 ? (num / den) * binHz : 0;
    const silent = this.features.loud < 0.03;
    while (this.onsetTimes.length && this.onsetTimes[0] < this.clock - 6) this.onsetTimes.shift();
    const target = {
      e: Math.min(1, this.features.loud * 1.15),
      b: Math.min(1, Math.max(0, (centroid - 600) / 3400)),
      o: Math.min(1, this.onsetTimes.length / 6 / 5),
      w: raw.bass / (raw.bass + raw.mid + 1e-4),
    };
    if (silent) return; // pauses between tracks shouldn't drag the mood toward "ocean"
    const k = 1 - Math.exp(-dt / 4);
    for (const key of Object.keys(target)) this.stats[key] += (target[key] - this.stats[key]) * k;
    this.mood.update(this.stats, dt);

    // Atmosphere: noisiness and how much the sound changes over the last minute.
    const mags = this.linMags || (this.linMags = new Float32Array(n));
    const topFlat = Math.min(n, Math.ceil(8000 / binHz));
    for (let i = 0; i < topFlat; i++) mags[i] = Math.pow(10, ((this.freq[i] / 255) * 70 - 100) / 20);
    const A = this.atmoStats;
    A.flat += (flatness(mags, 2, topFlat) - A.flat) * k;
    A.e = this.stats.e;
    A.b = this.stats.b;
    const H = this.history, acc = H.acc;
    acc.b += target.b; acc.e += target.e; acc.n++; acc.t += dt;
    if (acc.t >= 1) {
      H.b.push(acc.b / acc.n); H.e.push(acc.e / acc.n);
      if (H.b.length > 60) { H.b.shift(); H.e.shift(); }
      H.acc = { b: 0, e: 0, n: 0, t: 0 };
      const smooth = (a) => a.map((_, i) => { const w = a.slice(Math.max(0, i - 5), i + 6); return w.reduce((x, y) => x + y, 0) / w.length; });
      const sd = (a) => { const m = a.reduce((x, y) => x + y, 0) / a.length; return Math.sqrt(a.reduce((x, y) => x + (y - m) ** 2, 0) / a.length); };
      if (H.b.length >= 10) A.vari = Math.min(1, (sd(smooth(H.b)) + sd(smooth(H.e))) * 2.2);
    }
    this.atmo.update(A, dt);
  }

  dispose() {
    this.stopStream();
    if (this.ctx) this.ctx.close().catch(() => {});
  }
}
