// AFTERIMAGE app — wires the engine, audio and interface together.
import {
  MODES, ENVS, ATMOS, BOUNDS, MUTATIONS, chapterAt, defaultConfig, mutate, sanitize, encodeConfig, decodeConfig, History,
} from './core.js';
import { Engine, PALETTE_DEFS } from './engine.js';
import { AudioEngine } from './audio.js';
import { ENV_INFO } from './env.js';
import { scanSong } from './scan.js';

window.__afterimageReady = true;

const $ = (id) => document.getElementById(id);
const LOGO_SRC = document.querySelector('#splash img').getAttribute('src'); // kept: the splash is removed later
const inFrame = (() => { try { return window.self !== window.top; } catch { return true; } })();
const smallScreen = window.matchMedia('(max-width: 760px)');
const mobile = smallScreen.matches || /Mobi|Android|iPhone|iPad/i.test(navigator.userAgent);
const reduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
const store = {
  get(k) { try { return localStorage.getItem(k); } catch { return null; } },
  set(k, v) { try { localStorage.setItem(k, v); } catch { /* storage unavailable */ } },
};
const hex = (n) => `#${n.toString(16).padStart(6, '0')}`;
const fmtTime = (s) => {
  if (!Number.isFinite(s) || s < 0) return '0:00';
  const m = Math.floor(s / 60), ss = Math.floor(s % 60);
  return `${m}:${String(ss).padStart(2, '0')}`;
};

// ---------- toasts & fatal ----------
function toast(msg, { err = false, ms = 4200 } = {}) {
  const el = document.createElement('div');
  el.className = `toast glass${err ? ' err' : ''}`;
  el.textContent = msg;
  $('toasts').appendChild(el);
  while ($('toasts').children.length > 3) $('toasts').firstChild.remove();
  setTimeout(() => { el.style.transition = 'opacity .4s'; el.style.opacity = '0'; setTimeout(() => el.remove(), 450); }, ms);
}
function fatal(title, msg) {
  $('fatalTitle').textContent = title;
  $('fatalMsg').textContent = msg;
  $('fatal').hidden = false;
  hideSplash(true);
}
$('fatalReload').addEventListener('click', () => location.reload());

// ---------- splash ----------
let splashGone = false;
function hideSplash(now = false) {
  if (splashGone) return;
  splashGone = true;
  const s = $('splash');
  s.classList.add('out');
  setTimeout(() => s.remove(), now ? 0 : 1200);
  afterSplash();
}
setTimeout(hideSplash, reduced ? 1200 : 2800);
window.addEventListener('pointerdown', () => hideSplash(), { once: true });
window.addEventListener('keydown', () => hideSplash(), { once: true });

// ---------- initial config ----------
function readSharedCode() {
  if (location.hash.startsWith('#s=')) return location.hash.slice(3);
  try { return new URLSearchParams(location.search).get('s'); } catch { return null; }
}
const sharedCode = readSharedCode();
const sharedCfg = sharedCode ? decodeConfig(sharedCode) : null;
const startCfg = sharedCfg || defaultConfig();
let config = startCfg;
const history = new History(startCfg);

// ---------- engine ----------
const canvas = $('stage');
let engine;
try {
  engine = new Engine(canvas, {
    mobile, reducedMotion: reduced,
    onError(kind, detail) {
      if (detail) console.error('[afterimage]', kind, detail);
      if (kind === 'lost') fatal('Graphics paused', 'The graphics context was lost, which can happen after sleep or a driver reset. Reload to continue.');
      else if (kind === 'shader') fatal('Shader error', 'A shader failed to compile on this device. Try another browser, or update your graphics drivers.');
      else fatal('Rendering stopped', 'Something went wrong while drawing. Reload to start again.');
    },
  });
  engine.setConfig(config);
} catch (err) {
  console.error(err);
  fatal('Graphics unavailable', 'AFTERIMAGE needs WebGL 2. Turn on hardware acceleration in your browser settings, or try an up-to-date Chrome, Edge, Firefox or Safari.');
}

// ---------- audio ----------
const audioEl = $('audio');
const audio = new AudioEngine(audioEl);
if (engine) { engine.setFeatures(audio.features); engine.setSpectrum(audio.spec); }

// ---------- create panel ----------
const MODE_LABELS = { orb: 'Orb', fractal: 'Fractal', ribbon: 'Ribbon', void: 'Void' };
const MODE_HINTS = {
  orb: 'An organic, breathing sculpture',
  fractal: 'Crystalline facets and orbiting shards',
  ribbon: 'A knotted ribbon that flows and twists',
  void: 'A dark core with a swirling disk',
};
MODES.forEach((m, i) => {
  const b = document.createElement('button');
  b.setAttribute('role', 'radio');
  b.dataset.mode = m;
  b.textContent = MODE_LABELS[m].toUpperCase();
  b.title = `${MODE_HINTS[m]} (${i + 1})`;
  b.addEventListener('click', () => { if (config.mode !== m) commit({ ...config, mode: m }, 'form'); });
  $('modeSeg').appendChild(b);
});

Object.entries(PALETTE_DEFS).forEach(([key, P]) => {
  const b = document.createElement('button');
  b.className = 'swatch';
  b.setAttribute('role', 'radio');
  b.dataset.palette = key;
  const chip = document.createElement('i');
  chip.style.background = `radial-gradient(circle at 34% 30%, ${hex(P.acc)} 0%, ${hex(P.mid)} 38%, ${hex(P.base)} 78%)`;
  chip.style.boxShadow = `inset 0 0 0 1px ${hex(P.rim)}55, 0 0 12px ${hex(P.rim)}33`;
  b.append(chip, document.createTextNode(P.name === 'Monochrome' ? 'Mono' : P.name));
  b.title = P.name;
  b.addEventListener('click', () => { if (config.palette !== key) commit({ ...config, palette: key }, 'palette'); });
  $('palSeg').appendChild(b);
});

ENVS.forEach((env) => {
  const b = document.createElement('button');
  b.setAttribute('role', 'radio');
  b.dataset.env = env;
  b.textContent = ENV_INFO[env].label.toUpperCase();
  b.title = ENV_INFO[env].blurb;
  b.addEventListener('click', () => { if (config.env !== env) commit({ ...config, env }, 'env'); });
  $('envSeg').appendChild(b);
});

const ATMO_INFO = {
  auto: { label: 'Auto', short: 'AUTO', blurb: 'Reads the atmosphere from the sound' },
  natural: { label: 'Natural', short: 'NATURAL', blurb: 'Your palette as it is' },
  dark: { label: 'Dark', short: 'DARK', blurb: 'Drained colour, crushed shadows, blood-red highlights' },
  psychedelic: { label: 'Psychedelic', short: 'PSYCH', blurb: 'Sweeping hues and kaleidoscope trails' },
};
ATMOS.forEach((a) => {
  const b = document.createElement('button');
  b.setAttribute('role', 'radio');
  b.dataset.atmo = a;
  b.textContent = ATMO_INFO[a].short;
  b.title = `${ATMO_INFO[a].label}: ${ATMO_INFO[a].blurb}`;
  b.addEventListener('click', () => { if (config.atmo !== a) commit({ ...config, atmo: a }, 'atmo'); });
  $('atmoSeg').appendChild(b);
});

// ---------- song map (files are read ahead and split into chapters) ----------
let songMap = null;
let scanToken = 0;
let scanStatus = '';
let chapterIdx = -1;
const ENV_COLORS = { city: '#a988ff', desert: '#ffaa62', forest: '#62d27f', ocean: '#52b6ff', cosmos: '#c9c8d6' };

function setScanStatus(text) { scanStatus = text; $('journeyStatus').textContent = text; }

async function scanFile(file) {
  const token = ++scanToken;
  songMap = null;
  chapterIdx = -1;
  setScanStatus('Reading the whole song…');
  try {
    const buf = await file.arrayBuffer();
    if (token !== scanToken) return;
    const ab = await audio.ensure().decodeAudioData(buf);
    if (token !== scanToken) return;
    if (ab.duration > 25 * 60) { setScanStatus('Long track: reading it live instead'); return; }
    let mono = ab.getChannelData(0);
    if (ab.numberOfChannels > 1) {
      const r = ab.getChannelData(1), m = new Float32Array(mono.length);
      for (let i = 0; i < m.length; i++) m[i] = (mono[i] + r[i]) * 0.5;
      mono = m;
    }
    const map = await scanSong(mono, ab.sampleRate, {
      onProgress: (p) => { if (token === scanToken) setScanStatus(`Composing the world… ${Math.round(p * 100)}%`); },
      shouldStop: () => token !== scanToken,
    });
    if (!map || token !== scanToken) return;
    songMap = map;
    const route = map.journey.map((c) => ENV_INFO[c.env].label).join(' → ');
    setScanStatus(`${map.journey.length} chapter${map.journey.length > 1 ? 's' : ''} · ${ATMO_INFO[map.atmo].label.toLowerCase()} atmosphere`);
    if (config.env === 'auto' || config.atmo === 'auto') toast(`World composed: ${route}${map.atmo !== 'natural' ? `, in a ${map.atmo} atmosphere` : ''}.`, { ms: 5000 });
  } catch (err) {
    console.warn('[afterimage] scan failed', err);
    if (token === scanToken) setScanStatus("Couldn't read ahead; listening live instead");
  }
}

function drawJourney() {
  const cv = $('journeyCanvas');
  const w = cv.clientWidth, h = cv.clientHeight;
  if (!w) return;
  const dpr = Math.min(2, window.devicePixelRatio || 1);
  if (cv.width !== Math.round(w * dpr)) { cv.width = Math.round(w * dpr); cv.height = Math.round(h * dpr); }
  const g = cv.getContext('2d');
  g.setTransform(dpr, 0, 0, dpr, 0, 0);
  g.clearRect(0, 0, w, h);
  const dur = audioEl.duration;
  const prog = Number.isFinite(dur) && dur > 0 ? audioEl.currentTime / dur : 0;
  if (!songMap) {
    // shimmer while scanning
    g.fillStyle = 'rgba(220,214,255,0.08)';
    g.fillRect(0, h / 2 - 1, w, 2);
    g.fillStyle = 'rgba(220,214,255,0.5)';
    g.fillRect(prog * w - 1, 2, 2, h - 4);
    return;
  }
  const env = songMap.envelope, n = env.length, bw = w / n;
  const chapterColor = (t) => { const i = chapterAt(songMap.journey, t * songMap.duration); return ENV_COLORS[i >= 0 ? songMap.journey[i].env : 'cosmos']; };
  for (let i = 0; i < n; i++) {
    const x = i * bw, t = i / n, bh = Math.max(2, env[i] * (h - 4));
    g.globalAlpha = t <= prog ? 0.95 : 0.38;
    g.fillStyle = chapterColor(t);
    g.fillRect(x + 0.15 * bw, (h - bh) / 2, Math.max(1, bw * 0.7), bh);
  }
  g.globalAlpha = 1;
  g.fillStyle = 'rgba(4,3,6,0.9)';
  for (const c of songMap.journey.slice(1)) g.fillRect((c.start / songMap.duration) * w - 1, 0, 2, h);
  g.fillStyle = '#fff';
  g.fillRect(prog * w - 1, 0, 2, h);
}

// Which landscape and atmosphere are actually showing.
function effectiveEnv() {
  if (config.env !== 'auto') return config.env;
  if (audio.source === 'none') return 'cosmos';
  if (audio.source === 'file' && songMap) {
    const i = chapterAt(songMap.journey, audioEl.currentTime);
    return i >= 0 ? songMap.journey[i].env : songMap.env;
  }
  return audio.mood.env || 'cosmos';
}
function effectiveAtmo() {
  if (config.atmo !== 'auto') return config.atmo;
  if (audio.source === 'none') return 'natural';
  if (audio.source === 'file' && songMap) return songMap.atmo;
  return audio.atmo.env || 'natural';
}

let moodKey = '';
let lastAutoEnv = null;
let lastAutoAtmo = 'natural';
function paintMood(eff, atmo) {
  const fromMap = audio.source === 'file' && !!songMap;
  const listening = config.env === 'auto' && audio.source !== 'none' && !fromMap && !audio.mood.env;
  const ci = fromMap ? chapterAt(songMap.journey, audioEl.currentTime) : -1;
  const key = `${config.env}|${config.atmo}|${eff}|${atmo}|${audio.source}|${listening}|${ci}|${fromMap}`;
  if (key === moodKey) return;
  moodKey = key;
  const line = $('moodLine');
  line.textContent = '';
  const atmoNote = atmo !== 'natural' ? ` ${ATMO_INFO[atmo].label} atmosphere.` : '';
  if (config.env !== 'auto') { line.textContent = `${ENV_INFO[config.env].blurb}.${atmoNote}`; return; }
  if (audio.source === 'none') { line.textContent = 'Start some music and a world will grow from its mood.'; return; }
  if (listening) {
    const dot = document.createElement('span'); dot.className = 'dot';
    line.append(dot, 'Listening for the mood…');
    return;
  }
  const b = document.createElement('b');
  b.textContent = ENV_INFO[eff].label;
  const where = fromMap && songMap.journey.length > 1 ? ` · chapter ${ci + 1} of ${songMap.journey.length}` : '';
  line.append(b, `${where} · feels ${ENV_INFO[eff].mood || 'open'}.${atmoNote}`);
  if (eff !== lastAutoEnv) {
    const first = lastAutoEnv === null;
    lastAutoEnv = eff;
    if (fromMap && !first && !audioEl.paused) {
      toast(`Chapter ${ci + 1}: ${ENV_INFO[eff].label}`, { ms: 2500 });
      if (engine) { engine.land.pulse.r = 2.5; engine.land.pulse.amp = 1; }
    } else if (!fromMap) {
      toast(`This sounds ${ENV_INFO[eff].mood.split(',')[0]}. Building a${eff === 'ocean' ? 'n' : ''} ${ENV_INFO[eff].label.toLowerCase()}.`, { ms: 3500 });
    }
  }
  if (config.atmo === 'auto' && atmo !== lastAutoAtmo) {
    lastAutoAtmo = atmo;
    if (atmo === 'dark') toast('This sounds dark. Turning the lights down.', { ms: 3500 });
    else if (atmo === 'psychedelic') toast('This one wanders. Going psychedelic.', { ms: 3500 });
  }
}

['melt', 'fracture', 'warp', 'grow', 'unstable', 'universe'].forEach((op) => {
  const b = document.createElement('button');
  b.className = `btn ${op}`;
  b.textContent = MUTATIONS[op].label + (op === 'universe' ? '  ·  N' : '');
  b.title = MUTATIONS[op].hint;
  b.addEventListener('click', () => doMutate(op));
  $('mgrid').appendChild(b);
});
$('mutateBtn').addEventListener('click', () => doMutate('mutate'));

const SLIDERS = [
  ['deform', 'Deform', 'How far the surface bends'],
  ['motion', 'Motion', 'Speed of time and camera drift'],
  ['detail', 'Detail', 'Surface complexity and mesh density'],
  ['glow', 'Glow', 'Bloom intensity'],
  ['trail', 'Afterimage', 'How long each frame lingers'],
];
const sliderEls = {};
SLIDERS.forEach(([key, label, hint]) => {
  const [lo, hi] = BOUNDS[key];
  const row = document.createElement('label');
  row.className = 'slider';
  row.title = hint;
  const name = document.createElement('span');
  name.textContent = label;
  const input = document.createElement('input');
  input.type = 'range'; input.id = `sl-${key}`; input.min = lo; input.max = hi; input.step = 0.01;
  const out = document.createElement('output');
  row.append(name, input, out);
  input.addEventListener('input', () => {
    config = sanitize({ ...config, [key]: Number(input.value) });
    engine && engine.setConfig(config);
    paintSlider(key);
  });
  input.addEventListener('change', () => commit(config, 'tune'));
  sliderEls[key] = { input, out };
  $('sliders').appendChild(row);
});
function paintSlider(key) {
  const { input, out } = sliderEls[key];
  const [lo, hi] = BOUNDS[key];
  const pct = ((Number(input.value) - lo) / (hi - lo)) * 100;
  input.style.setProperty('--p', `${pct}%`);
  out.textContent = Math.round(pct);
}

// ---------- state changes ----------
function commit(cfg, op) {
  config = sanitize(cfg);
  const entry = history.push(config, op);
  engine && engine.setConfig(config);
  syncUI();
  scheduleThumb(entry);
}
function apply(entry) {
  config = entry.config;
  engine && engine.setConfig(config);
  syncUI();
  if (!entry.thumb) scheduleThumb(entry);
}
function doMutate(op) {
  hideSplash();
  commit(mutate(config, op), op);
}
function undo() { if (history.canUndo()) apply(history.undo()); }
function redo() { if (history.canRedo()) apply(history.redo()); }
$('undoBtn').addEventListener('click', undo);
$('redoBtn').addEventListener('click', redo);
$('resetBtn').addEventListener('click', () => {
  commit(startCfg, 'reset');
  toast(`Back to ${startCfg.seed}`);
});

function scheduleThumb(entry) {
  if (!engine) return;
  setTimeout(() => engine.requestThumb((url) => { if (url) { entry.thumb = url; renderLineage(); } }), 1100);
}

const OP_LABELS = { start: 'Start', form: 'Form', palette: 'Palette', env: 'Environment', atmo: 'Atmosphere', tune: 'Fine tune', reset: 'Reset', shared: 'Opened code' };
function renderLineage() {
  const box = $('lineage');
  box.textContent = '';
  history.items.forEach((item, i) => {
    const b = document.createElement('button');
    const label = `${MUTATIONS[item.op] ? MUTATIONS[item.op].label : (OP_LABELS[item.op] || item.op)} · ${item.config.seed} gen ${item.config.gen}`;
    b.title = label;
    b.setAttribute('aria-label', label);
    if (i === history.index) b.setAttribute('aria-current', 'true');
    if (item.thumb) {
      const img = document.createElement('img');
      img.src = item.thumb; img.alt = '';
      b.appendChild(img);
    } else {
      const P = PALETTE_DEFS[item.config.palette];
      b.style.background = `radial-gradient(circle, ${hex(P.mid)}, ${hex(P.base)} 70%)`;
    }
    b.addEventListener('click', () => apply(history.jump(i)));
    box.appendChild(b);
  });
  $('lineCount').textContent = history.items.length;
  const cur = box.children[history.index];
  if (cur) cur.scrollIntoView({ block: 'nearest', inline: 'nearest' });
}

function syncUI() {
  document.querySelectorAll('#modeSeg button').forEach((b) => b.setAttribute('aria-checked', String(b.dataset.mode === config.mode)));
  document.querySelectorAll('#palSeg button').forEach((b) => b.setAttribute('aria-checked', String(b.dataset.palette === config.palette)));
  document.querySelectorAll('#envSeg button').forEach((b) => b.setAttribute('aria-checked', String(b.dataset.env === config.env)));
  document.querySelectorAll('#atmoSeg button').forEach((b) => b.setAttribute('aria-checked', String(b.dataset.atmo === config.atmo)));
  for (const key of Object.keys(sliderEls)) {
    sliderEls[key].input.value = config[key];
    paintSlider(key);
  }
  $('seedName').textContent = config.seed;
  $('seedGen').textContent = config.gen;
  $('undoBtn').disabled = !history.canUndo();
  $('redoBtn').disabled = !history.canRedo();
  renderLineage();
  if (!inFrame) {
    try { window.history.replaceState(null, '', `#s=${encodeConfig(config)}`); } catch { /* file:// in some browsers */ }
  }
  if (!$('sharePop').hidden) fillShare();
}

// ---------- sources ----------
function showSource(kind) {
  $('srcIdle').hidden = kind !== 'none';
  $('srcFile').hidden = kind !== 'file';
  $('srcLive').hidden = !(kind === 'tab' || kind === 'mic');
}
const canTab = !!(navigator.mediaDevices && navigator.mediaDevices.getDisplayMedia) && !mobile;
if (!canTab) {
  $('tabBtn').hidden = true;
  $('fileBtn').classList.add('primary');
  $('idleNote').textContent = 'Or drop an audio file anywhere. Nothing leaves your device.';
}
const canMic = !!(navigator.mediaDevices && navigator.mediaDevices.getUserMedia);
if (!canMic) $('micBtn').hidden = true;

const AUDIO_EXT = /\.(mp3|wav|ogg|oga|m4a|aac|flac|opus|weba|webm|mp4)$/i;
let objectUrl = null;
let wantPlay = false;

function setFileStatus(text, err = false) {
  const s = $('fileStatus');
  s.textContent = text;
  s.classList.toggle('err', err);
}

function loadFile(file) {
  if (!file) return;
  hideSplash();
  const looksAudio = (file.type && (file.type.startsWith('audio/') || file.type === 'video/webm' || file.type === 'video/mp4')) || AUDIO_EXT.test(file.name);
  if (!looksAudio) {
    toast(`"${file.name}" isn't an audio file. Try MP3, WAV, OGG, M4A or FLAC.`, { err: true });
    return;
  }
  try { audio.useElement(); } catch (e) { toast(e.message, { err: true }); return; }
  if (objectUrl) URL.revokeObjectURL(objectUrl);
  objectUrl = URL.createObjectURL(file);
  audioEl.src = objectUrl;
  audioEl.volume = Number($('vol').value);
  $('trackName').textContent = file.name.replace(/\.[^.]+$/, '');
  $('trackName').title = file.name;
  $('seek').value = 0;
  $('tCur').textContent = '0:00';
  $('tDur').textContent = '0:00';
  setFileStatus('Loading…');
  showSource('file');
  lastAutoEnv = null;
  scanFile(file);
  wantPlay = true;
  audioEl.play().catch((err) => {
    if (err && err.name === 'NotAllowedError') setFileStatus('Press play');
  });
}

$('fileBtn').addEventListener('click', () => {
  try { audio.ensure(); } catch { /* reported on load */ }
  $('fileInput').click();
});
$('fileInput').addEventListener('change', (e) => {
  const f = e.target.files && e.target.files[0];
  e.target.value = '';
  loadFile(f);
});

function togglePlay() {
  if (audio.source !== 'file' || !audioEl.src) return;
  audio.ensure();
  if (audioEl.paused) audioEl.play().catch(() => setFileStatus('Playback failed', true));
  else audioEl.pause();
}
$('playBtn').addEventListener('click', togglePlay);

const PLAY_PATH = 'M4 2.5v11l9-5.5z', PAUSE_PATH = 'M4 2.5h3v11H4zM9 2.5h3v11H9z';
function paintPlay() {
  const playing = !audioEl.paused && !audioEl.ended;
  $('playIcon').innerHTML = `<path d="${playing ? PAUSE_PATH : PLAY_PATH}"/>`;
  $('playBtn').setAttribute('aria-label', playing ? 'Pause' : 'Play');
}
audioEl.addEventListener('play', paintPlay);
audioEl.addEventListener('pause', paintPlay);
audioEl.addEventListener('ended', paintPlay);
audioEl.addEventListener('playing', () => setFileStatus(''));
audioEl.addEventListener('waiting', () => setFileStatus('Buffering…'));
audioEl.addEventListener('loadedmetadata', () => {
  $('tDur').textContent = fmtTime(audioEl.duration);
  if (!wantPlay) setFileStatus('');
});
audioEl.addEventListener('canplay', () => { if ($('fileStatus').textContent === 'Loading…') setFileStatus(''); });
audioEl.addEventListener('error', () => {
  if (!audioEl.getAttribute('src')) return;
  setFileStatus("Can't play", true);
  toast("This file couldn't be played. It may be damaged, or in a format your browser can't decode. MP3, WAV and OGG work everywhere.", { err: true, ms: 6500 });
});

let seeking = false;
const seek = $('seek');
seek.addEventListener('input', () => {
  seeking = true;
  seek.style.setProperty('--p', `${seek.value / 10}%`);
  if (Number.isFinite(audioEl.duration)) $('tCur').textContent = fmtTime((seek.value / 1000) * audioEl.duration);
});
seek.addEventListener('change', () => {
  if (Number.isFinite(audioEl.duration)) audioEl.currentTime = (seek.value / 1000) * audioEl.duration;
  seeking = false;
});
const vol = $('vol');
const paintVol = () => vol.style.setProperty('--p', `${vol.value * 100}%`);
vol.addEventListener('input', () => { audioEl.volume = Number(vol.value); paintVol(); });
paintVol();

function ejectFile() {
  audioEl.pause();
  audioEl.removeAttribute('src');
  audioEl.load();
  if (objectUrl) { URL.revokeObjectURL(objectUrl); objectUrl = null; }
  wantPlay = false;
  scanToken++;
  songMap = null;
  setScanStatus('');
  if (audio.source === 'file') audio.source = 'none';
}
$('journeyCanvas').addEventListener('click', (e) => {
  const r = e.currentTarget.getBoundingClientRect();
  if (Number.isFinite(audioEl.duration)) audioEl.currentTime = ((e.clientX - r.left) / r.width) * audioEl.duration;
});
$('ejectBtn').addEventListener('click', () => { ejectFile(); showSource('none'); });

const frameNote = ' Inside the claude.ai preview this is blocked, so open the downloaded file instead.';
$('tabBtn').addEventListener('click', async () => {
  hideSplash();
  try {
    audio.ensure();
    ejectFile();
    await audio.useTab();
    $('liveName').textContent = 'Listening to a tab';
    $('liveNote').textContent = 'Play, pause and skip in that tab. The visuals follow whatever it plays.';
    showSource('tab');
  } catch (err) {
    if (err.code === 'noaudio') toast('No sound came through. Share again and switch on "Share tab audio" (Chrome and Edge).', { err: true, ms: 7000 });
    else if (err.code === 'unsupported') toast("This browser can't share tab audio. Use desktop Chrome or Edge, or try the mic or a file.", { err: true, ms: 6500 });
    else if (err.name === 'NotAllowedError') toast(`Tab sharing was cancelled or blocked.${inFrame ? frameNote : ''}`, { err: true, ms: 7000 });
    else toast(`Couldn't start tab capture: ${err.message}`, { err: true });
  }
});
$('micBtn').addEventListener('click', async () => {
  hideSplash();
  try {
    audio.ensure();
    ejectFile();
    await audio.useMic();
    $('liveName').textContent = 'Listening to the microphone';
    $('liveNote').textContent = 'Play music out loud near your device. Headphones won\'t be heard.';
    showSource('mic');
  } catch (err) {
    if (err.name === 'NotAllowedError') toast(`Microphone access was blocked. Allow it in your browser's site settings.${inFrame ? frameNote : ''}`, { err: true, ms: 7000 });
    else if (err.name === 'NotFoundError') toast('No microphone was found.', { err: true });
    else toast(`Couldn't open the microphone: ${err.message}`, { err: true });
  }
});
$('stopLiveBtn').addEventListener('click', () => { audio.stopStream(); showSource('none'); });
audio.onStreamEnded = (kind) => {
  showSource('none');
  toast(kind === 'tab' ? 'Tab sharing stopped.' : 'Microphone stopped.');
};

// drag & drop
let dragDepth = 0;
const hasFiles = (e) => e.dataTransfer && Array.from(e.dataTransfer.types || []).includes('Files');
window.addEventListener('dragenter', (e) => { if (!hasFiles(e)) return; e.preventDefault(); dragDepth++; $('drop').classList.add('on'); });
window.addEventListener('dragover', (e) => { if (!hasFiles(e)) return; e.preventDefault(); e.dataTransfer.dropEffect = 'copy'; });
window.addEventListener('dragleave', () => { dragDepth = Math.max(0, dragDepth - 1); if (!dragDepth) $('drop').classList.remove('on'); });
window.addEventListener('drop', (e) => {
  if (!hasFiles(e)) return;
  e.preventDefault();
  dragDepth = 0;
  $('drop').classList.remove('on');
  try { audio.ensure(); } catch { /* reported on load */ }
  loadFile(e.dataTransfer.files[0]);
});

// ---------- per-frame UI (no framework re-renders; direct DOM writes) ----------
const meterSpans = Array.from(document.querySelectorAll('.meters span'));
let lastT = performance.now();
function uiFrame(now) {
  requestAnimationFrame(uiFrame);
  const dt = Math.min(0.05, (now - lastT) / 1000);
  lastT = now;
  const f = audio.update(dt);
  const eff = effectiveEnv();
  const atmo = effectiveAtmo();
  if (engine) { engine.setEnvironment(eff); engine.setAtmosphere(atmo); }
  paintMood(eff, atmo);
  if (audio.source === 'file') drawJourney();
  if (audio.source !== 'none') {
    const vals = [f.bass, f.mid, f.treble];
    meterSpans.forEach((s, i) => { s.style.transform = `scaleY(${0.08 + 0.92 * vals[i % 3]})`; });
  }
  if (audio.source === 'file' && !seeking && Number.isFinite(audioEl.duration) && audioEl.duration > 0) {
    const v = (audioEl.currentTime / audioEl.duration) * 1000;
    seek.value = v;
    seek.style.setProperty('--p', `${v / 10}%`);
    $('tCur').textContent = fmtTime(audioEl.currentTime);
  }
}
requestAnimationFrame(uiFrame);
if (engine) engine.start();

// ---------- share ----------
function shareLink(code) {
  return `${location.href.split('#')[0].split('?')[0]}#s=${code}`;
}
function fillShare() {
  const code = encodeConfig(config);
  $('shareCode').value = code;
  $('shareLink').value = shareLink(code);
}
if (inFrame) $('linkBlock').hidden = true;
function openShare(open) {
  $('sharePop').hidden = !open;
  $('shareBtn').setAttribute('aria-expanded', String(open));
  if (open) { fillShare(); ($('linkBlock').hidden ? $('copyCode') : $('copyLink')).focus(); }
}
$('shareBtn').addEventListener('click', (e) => { e.stopPropagation(); openShare($('sharePop').hidden); });
document.addEventListener('pointerdown', (e) => {
  if (!$('sharePop').hidden && !$('sharePop').contains(e.target) && !$('shareBtn').contains(e.target)) openShare(false);
});
async function copyFrom(input, what) {
  try {
    await navigator.clipboard.writeText(input.value);
    toast(`${what} copied`);
  } catch {
    input.focus();
    input.select();
    let ok = false;
    try { ok = document.execCommand('copy'); } catch { ok = false; }
    toast(ok ? `${what} copied` : `Couldn't reach the clipboard. The ${what.toLowerCase()} is selected, so press Ctrl+C.`, { err: !ok });
  }
}
$('copyLink').addEventListener('click', () => copyFrom($('shareLink'), 'Link'));
$('copyCode').addEventListener('click', () => copyFrom($('shareCode'), 'Code'));
function openCode() {
  let raw = $('pasteCode').value.trim();
  const m = raw.match(/[#?&]s=([A-Za-z0-9_-]+)/);
  if (m) raw = m[1];
  const cfg = decodeConfig(raw);
  if (!cfg) { toast("That code isn't valid. Make sure it was copied completely.", { err: true }); return; }
  commit(cfg, 'shared');
  $('pasteCode').value = '';
  openShare(false);
  toast(`Opened ${cfg.seed}`);
}
$('loadCode').addEventListener('click', openCode);
$('pasteCode').addEventListener('keydown', (e) => { if (e.key === 'Enter') openCode(); });

// ---------- recording ----------
let rec = null;
let clip = null;
const MAX_REC = 30;
function pickMime() {
  const types = ['video/webm;codecs=vp9,opus', 'video/webm;codecs=vp8,opus', 'video/webm', 'video/mp4;codecs=avc1,mp4a.40.2', 'video/mp4'];
  return types.find((t) => window.MediaRecorder && MediaRecorder.isTypeSupported(t)) || '';
}
function startRec() {
  if (!engine) return;
  if (!window.MediaRecorder || !canvas.captureStream) {
    toast("This browser can't record clips.", { err: true });
    return;
  }
  hideSplash();
  const stream = canvas.captureStream(60);
  let audioTrack = null;
  try { audioTrack = audio.recordingTrack(); } catch { audioTrack = null; }
  if (audioTrack) stream.addTrack(audioTrack);
  const mime = pickMime();
  let mr;
  try {
    mr = new MediaRecorder(stream, mime ? { mimeType: mime, videoBitsPerSecond: 10_000_000 } : undefined);
  } catch (e) {
    stream.getTracks().forEach((t) => t.stop());
    toast(`Recording couldn't start: ${e.message}`, { err: true });
    return;
  }
  const chunks = [];
  const ownsAudio = audioTrack && audio.source !== 'file'; // cloned stream tracks are ours to stop
  mr.ondataavailable = (e) => { if (e.data && e.data.size) chunks.push(e.data); };
  mr.onstop = () => {
    stream.getVideoTracks().forEach((t) => t.stop());
    if (ownsAudio) audioTrack.stop();
    const type = mr.mimeType || mime || 'video/webm';
    const blob = new Blob(chunks, { type });
    const secs = Math.round((performance.now() - rec.t0) / 1000);
    rec = null;
    $('recBtn').classList.remove('on');
    $('recLbl').textContent = 'Record';
    clearInterval(recTimer);
    if (blob.size) showClip(blob, type.includes('mp4') ? 'mp4' : 'webm', secs);
    else toast('The recording came out empty. Try again.', { err: true });
  };
  mr.start(250);
  rec = { mr, t0: performance.now() };
  $('recBtn').classList.add('on');
  toast(audioTrack ? 'Recording with sound. Press R or the button to stop.' : 'Recording visuals only. Start some music to capture sound too.');
  recTimer = setInterval(() => {
    const s = (performance.now() - rec.t0) / 1000;
    $('recLbl').textContent = `${fmtTime(s)} / 0:${MAX_REC}`;
    if (s >= MAX_REC) stopRec();
  }, 250);
}
let recTimer = 0;
function stopRec() { if (rec && rec.mr.state !== 'inactive') rec.mr.stop(); }
$('recBtn').addEventListener('click', () => (rec ? stopRec() : startRec()));

function showClip(blob, ext, secs) {
  if (clip) URL.revokeObjectURL(clip.url);
  clip = { blob, ext, url: URL.createObjectURL(blob) };
  $('recVideo').src = clip.url;
  $('recInfo').textContent = `${secs}s · ${(blob.size / 1048576).toFixed(1)} MB · ${ext.toUpperCase()}`;
  $('recModal').hidden = false;
  $('recSave').focus();
}
function closeClip() {
  $('recModal').hidden = true;
  $('recVideo').pause();
  $('recVideo').removeAttribute('src');
  $('recVideo').load();
  if (clip) URL.revokeObjectURL(clip.url);
  clip = null;
}
$('recClose').addEventListener('click', closeClip);
$('recSave').addEventListener('click', async () => {
  if (!clip) return;
  const filename = `afterimage-${config.seed}.${clip.ext}`;
  let downloads = null;
  if (inFrame && window.claude && typeof window.claude.use === 'function') {
    try { downloads = await window.claude.use('downloads'); } catch { downloads = null; }
  }
  if (downloads) {
    try {
      await downloads.save({ filename, data: clip.blob });
      toast('Clip saved');
    } catch (e) {
      if (e && e.code !== 'declined') toast("The clip couldn't be saved here. Right-click the video and choose Save video as.", { err: true, ms: 6500 });
    }
    return;
  }
  const a = document.createElement('a');
  a.href = clip.url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
});

// ---------- fullscreen & perform mode ----------
const fsOk = document.fullscreenEnabled || document.webkitFullscreenEnabled;
if (!fsOk) $('fsBtn').hidden = true;
function toggleFs() {
  if (!fsOk) return;
  if (document.fullscreenElement) document.exitFullscreen().catch(() => {});
  else document.documentElement.requestFullscreen().catch(() => toast("Fullscreen isn't available here.", { err: true }));
}
$('fsBtn').addEventListener('click', toggleFs);
document.addEventListener('fullscreenchange', () => {
  $('fsBtn').setAttribute('aria-label', document.fullscreenElement ? 'Exit fullscreen' : 'Enter fullscreen');
});

let idleTimer = 0;
function togglePerform(force) {
  const on = typeof force === 'boolean' ? force : !document.body.classList.contains('perform');
  document.body.classList.toggle('perform', on);
  if (on) { openShare(false); toast('Interface hidden. Press H to bring it back.', { ms: 2500 }); }
}
window.addEventListener('pointermove', () => {
  document.body.classList.remove('idle');
  clearTimeout(idleTimer);
  idleTimer = setTimeout(() => document.body.classList.add('idle'), 2000);
}, { passive: true });

// ---------- mobile panel ----------
const panel = $('panel');
function setPanel(open) {
  panel.classList.toggle('collapsed', !open);
  document.body.classList.toggle('panel-open', open && smallScreen.matches);
  $('panelToggle').textContent = open ? 'Close' : 'Open';
  $('panelToggle').setAttribute('aria-expanded', String(open));
}
$('panelToggle').addEventListener('click', () => setPanel(panel.classList.contains('collapsed')));
setPanel(!smallScreen.matches);
smallScreen.addEventListener('change', (e) => setPanel(!e.matches));

// ---------- keyboard ----------
window.addEventListener('keydown', (e) => {
  const t = e.target;
  if (t && ((t.tagName === 'INPUT' && t.type !== 'range') || t.isContentEditable)) return;
  if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'z') {
    e.preventDefault();
    if (e.shiftKey) redo(); else undo();
    return;
  }
  if (e.ctrlKey || e.metaKey || e.altKey) return;
  const k = e.key.toLowerCase();
  if (k === 'm') doMutate('mutate');
  else if (k === 'n') doMutate('universe');
  else if (k === 'h') togglePerform();
  else if (k === 'e') commit({ ...config, env: ENVS[(ENVS.indexOf(config.env) + 1) % ENVS.length] }, 'env');
  else if (k === 'a') commit({ ...config, atmo: ATMOS[(ATMOS.indexOf(config.atmo) + 1) % ATMOS.length] }, 'atmo');
  else if (k === '?' || (k === '/' && e.shiftKey)) openTour(0);
  else if (k === 'f') toggleFs();
  else if (k === 'r') (rec ? stopRec() : startRec());
  else if (['1', '2', '3', '4'].includes(k)) commit({ ...config, mode: MODES[Number(k) - 1] }, 'form');
  else if (k === ' ' && audio.source === 'file' && !(t && (t.tagName === 'BUTTON' || t.tagName === 'INPUT'))) { e.preventDefault(); togglePlay(); }
  else if (k === 'escape') {
    if (!$('tour').hidden) closeTour();
    else if (!$('recModal').hidden) closeClip();
    else if (!$('sharePop').hidden) openShare(false);
    else togglePerform(false);
  }
});


// ---------- guided tour ----------
const TOUR = [
  {
    title: 'Music becomes a world',
    body: 'AFTERIMAGE turns any song into a living 3D sculpture and a landscape that grows from its mood. Four quick choices and you are in.',
    hero: true,
  },
  {
    title: 'Choose a form',
    body: 'The sculpture at the centre. Every form listens to the bass, mids and highs in its own way.',
    options: () => MODES.map((m) => ({ label: MODE_LABELS[m], hint: MODE_HINTS[m], on: config.mode === m, pick: () => commit({ ...config, mode: m }, 'form') })),
  },
  {
    title: 'Choose a palette',
    body: 'Colours for the sculpture and the world around it. You can mutate them later.',
    swatches: true,
    options: () => Object.entries(PALETTE_DEFS).map(([k, P]) => ({ label: P.name, swatch: P, on: config.palette === k, pick: () => commit({ ...config, palette: k }, 'palette') })),
  },
  {
    title: 'Choose a world',
    body: 'Auto lets the music decide: a quiet intro might become an ocean, the heavy part a neon city. The atmosphere sets the mood of the light.',
    options: () => ENVS.map((e) => ({ label: ENV_INFO[e].label, hint: ENV_INFO[e].blurb, on: config.env === e, pick: () => commit({ ...config, env: e }, 'env') })),
    options2: () => ATMOS.map((a) => ({ label: ATMO_INFO[a].label, hint: ATMO_INFO[a].blurb, on: config.atmo === a, pick: () => commit({ ...config, atmo: a }, 'atmo') })),
    label2: 'Atmosphere',
  },
  {
    title: 'Bring the music',
    body: 'Nothing is uploaded anywhere. Pick how the sound gets in:',
    sources: true,
  },
  {
    title: 'Play with it',
    body: 'The panel on the right holds everything. These keys are faster:',
    keys: [['M', 'Mutate'], ['N', 'New universe'], ['E', 'Change world'], ['A', 'Change atmosphere'], ['R', 'Record a clip'], ['H', 'Hide the interface'], ['F', 'Fullscreen'], ['?', 'This tour']],
    foot: 'Share sends your universe as a link. Your music never goes with it.',
  },
];
let tourAt = 0;

function el(tag, cls, text) {
  const e = document.createElement(tag);
  if (cls) e.className = cls;
  if (text != null) e.textContent = text;
  return e;
}

function renderTour() {
  const step = TOUR[tourAt];
  const body = $('tourBody');
  body.textContent = '';
  $('tourStep').textContent = `${tourAt + 1} / ${TOUR.length}`;
  if (step.hero) {
    const img = el('img', 'tour-hero');
    img.src = LOGO_SRC;
    img.alt = 'AFTERIMAGE';
    body.append(img);
  }
  const h = el('h2', 'tour-title', step.title);
  h.id = 'tourTitle';
  body.append(h, el('p', 'tour-text', step.body));

  const optionGrid = (list, swatches) => {
    const grid = el('div', `tour-opts${swatches ? ' sw' : ''}`);
    list.forEach((o) => {
      const b = el('button', 'tour-opt');
      b.setAttribute('aria-pressed', String(o.on));
      if (o.swatch) {
        const chip = el('i');
        chip.style.background = `radial-gradient(circle at 34% 30%, ${hex(o.swatch.acc)} 0%, ${hex(o.swatch.mid)} 38%, ${hex(o.swatch.base)} 78%)`;
        b.append(chip);
      }
      b.append(el('b', null, o.label));
      if (o.hint) b.append(el('span', null, o.hint));
      b.addEventListener('click', () => { o.pick(); renderTour(); });
      grid.append(b);
    });
    return grid;
  };
  if (step.options) body.append(optionGrid(step.options(), step.swatches));
  if (step.options2) body.append(el('div', 'label tour-sub', step.label2), optionGrid(step.options2()));

  if (step.sources) {
    const grid = el('div', 'tour-sources');
    const add = (title, desc, note, action, hide) => {
      if (hide) return;
      const b = el('button', 'tour-src');
      b.append(el('b', null, title), el('span', null, desc));
      if (note) b.append(el('em', null, note));
      b.addEventListener('click', () => { closeTour(); action(); });
      grid.append(b);
    };
    add('Listen to a tab', 'Play Spotify, YouTube Music or anything in another tab. Pick that tab, then switch on "Share tab audio".',
      'Chrome or Edge on a computer', () => $('tabBtn').click(), $('tabBtn').hidden);
    add('Open a song file', 'MP3, WAV, FLAC and more. AFTERIMAGE reads the whole song first and builds a journey, one landscape per chapter.',
      'Best results', () => $('fileBtn').click());
    add('Use the microphone', 'Play music out loud near your device and the world reacts to the room.',
      'Headphones won\'t be heard', () => $('micBtn').click(), $('micBtn').hidden);
    body.append(grid);
  }
  if (step.keys) {
    const grid = el('div', 'tour-keys');
    step.keys.forEach(([k, d]) => { const row = el('div'); row.append(el('span', 'kbd', k), el('span', null, d)); grid.append(row); });
    body.append(grid);
  }
  if (step.foot) body.append(el('p', 'tour-foot', step.foot));

  const dots = $('tourDots');
  dots.textContent = '';
  TOUR.forEach((_, i) => {
    const d = el('button', 'tour-dot');
    d.setAttribute('aria-label', `Step ${i + 1}`);
    if (i === tourAt) d.setAttribute('aria-current', 'step');
    d.addEventListener('click', () => { tourAt = i; renderTour(); });
    dots.append(d);
  });
  $('tourBack').disabled = tourAt === 0;
  $('tourNext').textContent = tourAt === 0 ? 'Start' : tourAt === TOUR.length - 1 ? 'Start creating' : step.sources ? 'Later' : 'Next';
}

function openTour(i = 0) {
  hideSplash();
  openShare(false);
  tourAt = i;
  renderTour();
  $('tour').hidden = false;
  document.body.classList.add('touring');
  $('tourNext').focus();
}
function closeTour() {
  $('tour').hidden = true;
  document.body.classList.remove('touring');
  store.set('afterimage.toured', '1');
}
$('tourNext').addEventListener('click', () => {
  if (tourAt >= TOUR.length - 1) { closeTour(); return; }
  tourAt++;
  renderTour();
});
$('tourBack').addEventListener('click', () => { if (tourAt > 0) { tourAt--; renderTour(); } });
$('tourSkip').addEventListener('click', closeTour);
$('helpBtn').addEventListener('click', () => openTour(0));
$('tour').addEventListener('keydown', (e) => {
  if (e.key === 'ArrowRight') { e.stopPropagation(); $('tourNext').click(); }
  else if (e.key === 'ArrowLeft') { e.stopPropagation(); $('tourBack').click(); }
});

// ---------- boot ----------
syncUI();
showSource('none');
function afterSplash() {
  if (sharedCode && !sharedCfg) {
    toast("That shared link was damaged, so here's the default universe instead.", { err: true, ms: 6000 });
  } else if (sharedCfg) {
    toast(`Opened ${sharedCfg.seed}. Bring your own music.`);
  }
  if (!store.get('afterimage.toured')) setTimeout(() => openTour(0), sharedCfg ? 1600 : 300);
}
setTimeout(() => { if (engine) scheduleThumb(history.items[0]); }, 1800);

window.addEventListener('pagehide', () => {
  if (objectUrl) URL.revokeObjectURL(objectUrl);
  audio.dispose();
  if (engine) engine.dispose();
});

// Handle for debugging from the console.
window.afterimage = { get config() { return config; }, get songMap() { return songMap; }, audio, engine, mutate: doMutate };
