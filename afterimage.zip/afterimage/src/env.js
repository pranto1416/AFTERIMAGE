// AFTERIMAGE landscapes — City, Desert, Forest, Ocean.
// Every landscape reads the same 64-band spectrum texture and audio uniforms,
// rises out of the ground when chosen and sinks away when left.
import * as THREE from 'https://cdn.jsdelivr.net/npm/three@0.160.0/build/three.module.js';
import { NOISE } from './glsl.js';
import { mulberry32 } from './core.js';

export const ENV_INFO = {
  auto:   { label: 'Auto',   blurb: 'Reads the mood of the music and picks a landscape' },
  cosmos: { label: 'Cosmos', blurb: 'No landscape; the sculpture alone in space' },
  city:   { label: 'City',   blurb: 'A skyline where every building is a frequency band', mood: 'energetic, bright, busy' },
  desert: { label: 'Desert', blurb: 'Dunes that swell with the bass', mood: 'warm, slow, heavy' },
  forest: { label: 'Forest', blurb: 'Trees sway with the mids; fireflies flash with the highs', mood: 'organic, airy, acoustic' },
  ocean:  { label: 'Ocean',  blurb: 'Swells follow the bass, foam follows the highs', mood: 'calm, flowing' },
};

const LANDS = ['cosmos', 'city', 'desert', 'forest', 'ocean'];
const TINTS = {
  city: 0x9a4dff, desert: 0xff9a4a, forest: 0x4fbf6a, ocean: 0x2f8fd8, cosmos: 0x000000,
};
const GROUND = -1.6;
const RING = 7.4; // camera orbit radius over landscapes; kept clear of buildings and trees

// ---------- GLSL ----------
const COMMON = /* glsl */`
uniform float uTime, uBass, uMidE, uTreble, uKick, uFade, uPulse, uPulseAmp;
uniform sampler2D uSpec;
uniform vec3 uColBase, uColMid, uColAcc, uColRim, uBgCol, uTint, uFogCol;
float spec(float x){ return texture2D(uSpec, vec2(clamp(x, 0.0, 1.0)*0.984 + 0.008, 0.5)).r; }
float hash1(vec2 p){ return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453); }
vec3 fogMix(vec3 col, vec3 wp, float near, float far){
  return mix(col, uFogCol, smoothstep(near, far, length(wp - cameraPosition)));
}
vec3 tinted(vec3 c, float amt){ return mix(c, uTint * (0.25 + dot(c, vec3(0.333))*1.4), amt); }
float sink(){ return (1.0 - uFade) * 3.2; }
// The spectrum laid around the compass: each direction listens to its own band, mirrored so it wraps.
float bandAt(vec2 xz){ return spec(abs(atan(xz.y, xz.x)) / 3.14159); }
// A ring that races outward on every strong beat.
float shock(vec2 xz){ return exp(-abs(length(xz) - uPulse) * 1.4) * uPulseAmp; }
${NOISE}
`;

// City ----------------------------------------------------------
const CITY_VERT = /* glsl */`
${COMMON}
attribute float aBin;
attribute float aSeed;
varying vec3 vWorld; varying vec3 vN; varying vec3 vLocal; varying float vS; varying float vSeed; varying float vH;
void main(){
  float s = spec(aBin);
  float hMul = 0.3 + 1.5*s + 0.35*uKick*step(0.6, aSeed) + 0.6*shock(instanceMatrix[3].xz);
  vec3 p = position;
  p.y *= hMul;
  vec4 wp = modelMatrix * instanceMatrix * vec4(p, 1.0);
  wp.y -= sink();
  vec3 sc = vec3(length(instanceMatrix[0].xyz), length(instanceMatrix[1].xyz), length(instanceMatrix[2].xyz));
  vLocal = vec3(position.x*sc.x, p.y*sc.y, position.z*sc.z);
  vH = hMul * sc.y;
  vN = normalize(mat3(modelMatrix) * mat3(instanceMatrix) * normal);
  vWorld = wp.xyz; vS = s; vSeed = aSeed;
  gl_Position = projectionMatrix * viewMatrix * wp;
}`;
const CITY_FRAG = /* glsl */`
${COMMON}
varying vec3 vWorld; varying vec3 vN; varying vec3 vLocal; varying float vS; varying float vSeed; varying float vH;
void main(){
  vec3 N = normalize(vN);
  vec3 V = normalize(cameraPosition - vWorld);
  float side = 1.0 - step(0.5, abs(N.y));
  float u = abs(N.x) > 0.5 ? vLocal.z : vLocal.x;
  vec2 g = vec2(u*7.0, vLocal.y*6.0);
  vec2 cell = fract(g);
  float win = step(0.22, cell.x)*step(cell.x, 0.78)*step(0.28, cell.y)*step(cell.y, 0.78);
  float rnd = hash1(floor(g) + vec2(vSeed*97.0, vSeed*13.0));
  float lit = step(0.62 - 0.35*uTreble - 0.3*vS, rnd);
  float flick = 0.75 + 0.25*sin(uTime*7.0 + rnd*40.0);
  vec3 winCol = mix(uColAcc, uColRim, step(0.5, fract(rnd*7.3)));
  float diff = 0.4 + 0.6*max(dot(N, normalize(vec3(0.3, 0.8, 0.5))), 0.0);
  vec3 col = tinted(uColBase, 0.25) * 0.35 * diff;
  col += winCol * win * lit * side * flick * (0.45 + 1.6*vS);
  float roof = smoothstep(vH - 0.05, vH, vLocal.y);
  col += uColRim * roof * (0.18 + 1.6*uKick + 1.1*vS);
  col += uColRim * pow(1.0 - clamp(abs(dot(N, V)), 0.0, 1.0), 3.0) * 0.12;
  col = fogMix(col, vWorld, 8.0, 30.0);
  gl_FragColor = vec4(col * uFade, 1.0);
}`;
const GRID_VERT = /* glsl */`
${COMMON}
varying vec3 vWorld;
void main(){
  vec4 wp = modelMatrix * vec4(position, 1.0);
  wp.y -= sink();
  vWorld = wp.xyz;
  gl_Position = projectionMatrix * viewMatrix * wp;
}`;
const GRID_FRAG = /* glsl */`
${COMMON}
varying vec3 vWorld;
void main(){
  vec2 q = vWorld.xz * 0.9;
  vec2 g = abs(fract(q - 0.5) - 0.5) / fwidth(q);
  float line = 1.0 - min(min(g.x, g.y), 1.0);
  float r = length(vWorld.xz);
  float road = exp(-pow((r - ${RING.toFixed(1)}) / 0.9, 2.0));
  float ring = exp(-abs(r - uPulse) * 1.4) * uPulseAmp;
  vec3 col = uBgCol * 0.5;
  col += uColRim * line * 0.18 * (0.35 + uBass);
  col += uColMid * road * 0.10;
  col += uColAcc * ring * 0.9;
  col = fogMix(col, vWorld, 8.0, 32.0);
  gl_FragColor = vec4(col * uFade, 1.0);
}`;

// Desert --------------------------------------------------------
const DESERT_VERT = /* glsl */`
${COMMON}
varying vec3 vWorld; varying vec3 vN; varying float vCrest;
float crestOf(vec2 xz){
  vec2 q = xz * 0.11;
  float n = 1.0 - abs(snoise(vec3(q.x*0.8 + uTime*0.008, q.y*1.3, 1.7)));
  return pow(n, 2.2);
}
float dune(vec2 xz){
  float r = length(xz);
  float shape = smoothstep(2.5, 6.0, r) * (1.0 - 0.75*exp(-pow((r - ${RING.toFixed(1)}) / 1.7, 2.0)));
  float h = crestOf(xz) * 1.5 * (0.45 + 0.35*uBass + 1.0*bandAt(xz)) + snoise(vec3(xz*0.33, 4.2)) * 0.16 + 0.55*shock(xz);
  float ripple = sin(dot(xz, vec2(0.7, 0.7))*9.0 + snoise(vec3(xz*0.5, 2.0))*4.0 - uTime*1.2) * 0.012 * (0.5 + 1.5*uMidE);
  return h * shape + ripple;
}
void main(){
  vec4 wp = modelMatrix * vec4(position, 1.0);
  vec2 xz = wp.xz;
  float e = 0.06;
  float h = dune(xz);
  vec3 P0 = vec3(xz.x, h, xz.y);
  vec3 P1 = vec3(xz.x + e, dune(xz + vec2(e, 0.0)), xz.y);
  vec3 P2 = vec3(xz.x, dune(xz + vec2(0.0, e)), xz.y + e);
  vN = normalize(cross(P2 - P0, P1 - P0));
  vCrest = crestOf(xz);
  wp.y = ${GROUND.toFixed(1)} + h - sink();
  vWorld = wp.xyz;
  gl_Position = projectionMatrix * viewMatrix * wp;
}`;
const DESERT_FRAG = /* glsl */`
${COMMON}
varying vec3 vWorld; varying vec3 vN; varying float vCrest;
void main(){
  vec3 N = normalize(vN);
  vec3 V = normalize(cameraPosition - vWorld);
  vec3 L = normalize(vec3(-0.35, 0.32, -1.0));
  float diff = max(dot(N, L)*0.5 + 0.5, 0.0);
  diff = diff * diff;
  vec3 sand = tinted(mix(uColBase*1.6, uColMid, 0.45), 0.6);
  vec3 col = sand * (0.08 + 1.1*diff);
  col += uColRim * pow(1.0 - max(dot(N, V), 0.0), 4.0) * 0.3;
  col += uColAcc * smoothstep(0.82, 1.0, vCrest) * (0.08 + 0.35*uBass);
  float sparkle = step(0.986, hash1(floor(vWorld.xz*40.0) + floor(uTime*6.0)));
  col += uColAcc * sparkle * uTreble * uTreble * 2.5;
  col = fogMix(col, vWorld, 9.0, 34.0);
  gl_FragColor = vec4(col * uFade, 1.0);
}`;

// Forest --------------------------------------------------------
const HILL = /* glsl */`
float hill(vec2 xz){ return snoise(vec3(xz*0.08, 9.0)) * 0.5 * smoothstep(3.0, 8.0, length(xz)); }
`;
const FOREST_GROUND_VERT = /* glsl */`
${COMMON}
${HILL}
varying vec3 vWorld; varying vec3 vN;
void main(){
  vec4 wp = modelMatrix * vec4(position, 1.0);
  float e = 0.2;
  float h = hill(wp.xz);
  vN = normalize(vec3(h - hill(wp.xz + vec2(e, 0.0)), e, h - hill(wp.xz + vec2(0.0, e))));
  wp.y = ${GROUND.toFixed(1)} + h - sink();
  vWorld = wp.xyz;
  gl_Position = projectionMatrix * viewMatrix * wp;
}`;
const FOREST_GROUND_FRAG = /* glsl */`
${COMMON}
varying vec3 vWorld; varying vec3 vN;
void main(){
  vec3 N = normalize(vN);
  float diff = max(dot(N, normalize(vec3(0.3, 0.9, 0.2))), 0.0);
  float moss = snoise(vec3(vWorld.xz*0.6, 1.0))*0.5 + 0.5;
  vec3 col = tinted(uColBase*1.1, 0.7) * (0.08 + 0.4*diff) * (0.7 + 0.5*moss);
  col = fogMix(col, vWorld, 9.0, 32.0);
  gl_FragColor = vec4(col * uFade, 1.0);
}`;
const TREE_VERT = /* glsl */`
${COMMON}
${HILL}
attribute float aBin;
attribute float aSeed;
varying vec3 vWorld; varying float vT; varying float vS;
void main(){
  vec3 p = position;
  float t = clamp(p.y, 0.0, 1.0);
  float s = spec(aBin);
  p.y *= 1.0 + s*0.35;
  vec4 base = modelMatrix * instanceMatrix * vec4(0.0, 0.0, 0.0, 1.0);
  vec4 wp = modelMatrix * instanceMatrix * vec4(p, 1.0);
  float height = length(instanceMatrix[1].xyz);
  float bump = shock(base.xz);
  wp.y += hill(base.xz) + (wp.y - base.y) * 0.4 * bump;
  vS = s + bump;
  float sway = sin(uTime*1.4 + aSeed*30.0 + base.x*0.2) * (0.05 + 0.22*uMidE) + uKick*0.07*sin(aSeed*10.0);
  wp.x += sway * t*t * height * 0.5;
  wp.z += sway * 0.5 * t*t * height * 0.5;
  wp.y -= sink();
  vWorld = wp.xyz; vT = t;
  gl_Position = projectionMatrix * viewMatrix * wp;
}`;
const TREE_FRAG = /* glsl */`
${COMMON}
varying vec3 vWorld; varying float vT; varying float vS;
void main(){
  vec3 V = normalize(cameraPosition - vWorld);
  vec3 N = normalize(cross(dFdx(vWorld), dFdy(vWorld)));
  if (dot(N, V) < 0.0) N = -N;
  float diff = max(dot(N, normalize(vec3(0.3, 0.9, 0.2))), 0.0);
  vec3 leaf = tinted(mix(uColBase*1.1, uColMid*0.55, vT), 0.75);
  vec3 col = leaf * (0.1 + 0.7*diff);
  col += uColRim * pow(1.0 - max(dot(N, V), 0.0), 2.5) * (0.2 + 0.7*uMidE);
  col += uColAcc * smoothstep(0.82, 1.0, vT) * (1.3*uTreble + 0.5*vS);
  col = fogMix(col, vWorld, 9.0, 32.0);
  gl_FragColor = vec4(col * uFade, 1.0);
}`;
const FLY_VERT = /* glsl */`
${COMMON}
attribute float aSeed;
uniform float uPix;
varying float vGlow;
void main(){
  vec3 p = position;
  p.x += sin(uTime*0.5 + aSeed*20.0) * 0.4;
  p.z += cos(uTime*0.4 + aSeed*13.0) * 0.4;
  p.y += sin(uTime*0.8 + aSeed*7.0) * 0.25 - sink();
  vec4 mv = modelViewMatrix * vec4(p, 1.0);
  float blink = pow(0.5 + 0.5*sin(uTime*(1.5 + aSeed*2.0) + aSeed*50.0), 6.0);
  vGlow = blink * (0.3 + 1.6*uTreble) + uKick*0.3;
  gl_PointSize = (6.0 + 10.0*vGlow) * uPix / max(-mv.z, 0.1);
  gl_Position = projectionMatrix * mv;
}`;
const FLY_FRAG = /* glsl */`
${COMMON}
varying float vGlow;
void main(){
  float d = length(gl_PointCoord - 0.5);
  float a = smoothstep(0.5, 0.0, d);
  gl_FragColor = vec4(mix(uColAcc, uColRim, 0.4) * a*a * vGlow * uFade * 1.6, 1.0);
}`;

// Ocean ---------------------------------------------------------
const OCEAN_VERT = /* glsl */`
${COMMON}
varying vec3 vWorld; varying vec3 vN; varying float vCrest;
float waves(vec2 xz){
  float A = (0.06 + 0.22*uBass) * (0.5 + 1.4*bandAt(xz));
  float t = uTime * 1.3;
  float r = length(xz);
  float h = sin(dot(xz, vec2(0.38, 0.12)) - t*0.9) * A;
  h += sin(dot(xz, vec2(-0.21, 0.33))*1.4 - t*1.1) * A*0.6;
  h += sin(dot(xz, vec2(0.12, -0.5))*2.3 - t*1.6) * A*0.3*(1.0 + uMidE);
  h += snoise(vec3(xz*0.25, t*0.2)) * A*0.5;
  h += snoise(vec3(xz*1.4, t*0.6)) * 0.03 * (0.4 + uMidE + uTreble);
  h += sin(r*2.4 - uTime*5.0) * 0.08 * uBass * exp(-r*0.06);
  h += 0.5 * shock(xz);
  return h;
}
void main(){
  vec4 wp = modelMatrix * vec4(position, 1.0);
  vec2 xz = wp.xz;
  float e = 0.08;
  float h = waves(xz);
  vN = normalize(vec3(h - waves(xz + vec2(e, 0.0)), e, h - waves(xz + vec2(0.0, e))));
  vCrest = h / (0.16 + 0.5*uBass + 0.3*bandAt(xz));
  wp.y = ${GROUND.toFixed(1)} + h - sink();
  vWorld = wp.xyz;
  gl_Position = projectionMatrix * viewMatrix * wp;
}`;
const OCEAN_FRAG = /* glsl */`
${COMMON}
uniform vec3 uMoon;
varying vec3 vWorld; varying vec3 vN; varying float vCrest;
void main(){
  vec3 N = normalize(vN);
  vec3 V = normalize(cameraPosition - vWorld);
  float fres = pow(1.0 - max(dot(N, V), 0.0), 5.0) * 0.9 + 0.04;
  vec3 deep = tinted(uColBase, 0.6) * 0.7;
  vec3 sky = tinted(mix(uColMid*0.5, uColRim*0.5, 0.5), 0.3);
  vec3 col = mix(deep, sky, fres);
  vec3 L = normalize(uMoon - vWorld);
  vec3 R = reflect(-V, N);
  float rl = max(dot(R, L), 0.0);
  col += uColAcc * pow(rl, 40.0) * (0.9 + 2.0*uKick);
  col += uColRim * pow(rl, 6.0) * 0.16;
  col += mix(uColAcc, vec3(1.0), 0.5) * smoothstep(0.55, 0.95, vCrest) * (0.15 + 0.8*uTreble) * 0.35;
  col = fogMix(col, vWorld, 8.0, 40.0);
  gl_FragColor = vec4(col * uFade, 1.0);
}`;

// Cosmos --------------------------------------------------------
const RINGS_VERT = /* glsl */`
${COMMON}
attribute float aAngle;
attribute float aRing;
attribute float aSeed;
uniform float uPix;
varying float vGlow; varying float vS;
void main(){
  float a = aAngle;
  float s = spec(abs(mod(a + aRing, 6.28318) - 3.14159) / 3.14159);
  float R = 1.6 + aRing*0.45;
  float r = R + s*(0.3 + aRing*0.14) + exp(-abs(R - uPulse*0.22) * 3.0) * uPulseAmp * 0.45;
  vec3 p = vec3(cos(a)*r, sin(a*3.0 + uTime*0.6 + aRing*2.0)*0.05 + (aSeed - 0.5)*0.04, sin(a)*r);
  p.yz = rot2(0.42 + aRing*0.3) * p.yz;
  p.xz = rot2(uTime*0.05*(1.0 + aRing*0.4) + aRing*1.3) * p.xz;
  vec4 mv = modelViewMatrix * vec4(p, 1.0);
  vS = s;
  vGlow = (0.2 + 1.5*s + 0.4*uKick) * uFade;
  gl_PointSize = (12.0 + 34.0*s) * uPix / max(-mv.z, 0.1);
  gl_Position = projectionMatrix * mv;
}`;
const RINGS_FRAG = /* glsl */`
${COMMON}
varying float vGlow; varying float vS;
void main(){
  float d = length(gl_PointCoord - 0.5);
  float a = smoothstep(0.5, 0.0, d);
  gl_FragColor = vec4(mix(uColRim, uColAcc, vS) * a * a * vGlow, 1.0);
}`;

// Sky -----------------------------------------------------------
const SKY_VERT = /* glsl */`
varying vec3 vDir;
void main(){
  vDir = normalize(position);
  gl_Position = projectionMatrix * viewMatrix * modelMatrix * vec4(position, 1.0);
}`;
const SKY_FRAG = /* glsl */`
uniform vec3 uBgCol, uHorizon;
uniform float uMix;
varying vec3 vDir;
void main(){
  float y = vDir.y;
  vec3 col = mix(uHorizon, uBgCol, smoothstep(0.0, 0.32, y));
  gl_FragColor = vec4(mix(uBgCol, col, uMix), 1.0);
}`;

// ---------- Landscapes ----------
export class Landscapes {
  constructor(scene, shared, { mobile = false } = {}) {
    this.scene = scene;
    this.mobile = mobile;
    this.target = null;
    this.lands = {};
    this.disposables = [];
    this.mix = 0;
    this.pulse = { r: 99, amp: 0, prevKick: 0 };

    this.specData = new Uint8Array(64);
    this.specTex = new THREE.DataTexture(this.specData, 64, 1, THREE.RedFormat, THREE.UnsignedByteType);
    this.specTex.minFilter = THREE.LinearFilter;
    this.specTex.magFilter = THREE.LinearFilter;
    this.specTex.needsUpdate = true;
    this.disposables.push(this.specTex);

    this.shared = {
      ...shared,
      uSpec: { value: this.specTex },
      uBgCol: { value: new THREE.Color() },
      uTint: { value: new THREE.Color() },
      uFogCol: { value: new THREE.Color() },
      uPulse: { value: 99 },
      uPulseAmp: { value: 0 },
    };

    this.skyU = { uBgCol: this.shared.uBgCol, uHorizon: this.shared.uFogCol, uMix: { value: 0 } };
    const skyMat = new THREE.ShaderMaterial({ vertexShader: SKY_VERT, fragmentShader: SKY_FRAG, uniforms: this.skyU, side: THREE.BackSide, depthWrite: false });
    this.sky = new THREE.Mesh(new THREE.SphereGeometry(45, 32, 16), skyMat);
    this.sky.renderOrder = -10;
    this.sky.frustumCulled = false;
    this.sky.visible = false;
    scene.add(this.sky);
    this.disposables.push(skyMat, this.sky.geometry);
  }

  uniformsFor() {
    return { ...this.shared, uFade: { value: 0 } };
  }

  material(vert, frag, uniforms, extra = {}) {
    const m = new THREE.ShaderMaterial({ vertexShader: vert, fragmentShader: frag, uniforms, ...extra });
    this.disposables.push(m);
    return m;
  }

  mesh(geom, mat) {
    const m = new THREE.Mesh(geom, mat);
    m.frustumCulled = false;
    this.disposables.push(geom);
    return m;
  }

  build(name) {
    if (this.lands[name]) return this.lands[name];
    const u = this.uniformsFor();
    const group = new THREE.Group();
    const seg = (d, m) => (this.mobile ? m : d);
    const rng = mulberry32(name.length * 7919 + 17);
    let tick = null;

    if (name === 'cosmos') {
      const rings = 5, per = this.mobile ? 260 : 420;
      const count = rings * per;
      const pos = new Float32Array(count * 3), ang = new Float32Array(count), ring = new Float32Array(count), seed = new Float32Array(count);
      for (let k = 0; k < count; k++) {
        ring[k] = Math.floor(k / per);
        ang[k] = ((k % per) / per) * Math.PI * 2 + rng() * 0.01;
        seed[k] = rng();
      }
      const g = new THREE.BufferGeometry();
      g.setAttribute('position', new THREE.BufferAttribute(pos, 3));
      g.setAttribute('aAngle', new THREE.BufferAttribute(ang, 1));
      g.setAttribute('aRing', new THREE.BufferAttribute(ring, 1));
      g.setAttribute('aSeed', new THREE.BufferAttribute(seed, 1));
      const pts = new THREE.Points(g, this.material(RINGS_VERT, RINGS_FRAG, { ...u, uPix: this.shared.uPix }, { transparent: true, depthWrite: false, blending: THREE.AdditiveBlending }));
      pts.frustumCulled = false;
      this.disposables.push(g);
      group.add(pts);
    } else if (name === 'city') {
      const box = new THREE.BoxGeometry(1, 1, 1);
      box.translate(0, 0.5, 0);
      const spots = [];
      for (let i = -15; i <= 15; i++) {
        for (let j = -15; j <= 15; j++) {
          const x = i + (rng() - 0.5) * 0.3, z = j + (rng() - 0.5) * 0.3;
          const r = Math.hypot(x, z);
          if (r < 3 || r > 17 || (r > RING - 1.3 && r < RING + 2.2)) continue; // plaza and ring road
          if (Math.abs(x) < 0.5 || Math.abs(z) < 0.5 || rng() < 0.12) continue; // avenues and gaps
          spots.push([x, z, r]);
        }
      }
      const n = this.mobile ? Math.min(spots.length, 380) : spots.length;
      const inst = new THREE.InstancedMesh(box, this.material(CITY_VERT, CITY_FRAG, u), n);
      const aBin = new Float32Array(n), aSeed = new Float32Array(n);
      const m4 = new THREE.Matrix4();
      for (let k = 0; k < n; k++) {
        const [x, z, r] = spots[k];
        const w = 0.42 + rng() * 0.38;
        const inner = r < RING;
        const h = inner ? 0.35 + rng() * 0.9 : (0.6 + rng() ** 2 * 3.2) * (1 + 0.8 * Math.exp(-((r - 11) ** 2) / 8));
        m4.makeScale(w, h, w * (0.8 + rng() * 0.4));
        m4.setPosition(x, GROUND, z);
        inst.setMatrixAt(k, m4);
        aBin[k] = Math.abs(Math.atan2(z, x)) / Math.PI; // the spectrum wraps around the skyline
        aSeed[k] = rng();
      }
      box.setAttribute('aBin', new THREE.InstancedBufferAttribute(aBin, 1));
      box.setAttribute('aSeed', new THREE.InstancedBufferAttribute(aSeed, 1));
      inst.frustumCulled = false;
      this.disposables.push(box);
      group.add(inst);
      const ground = this.mesh(new THREE.PlaneGeometry(80, 80, 1, 1).rotateX(-Math.PI / 2).translate(0, GROUND - 0.001, 0),
        this.material(GRID_VERT, GRID_FRAG, u));
      group.add(ground);
    } else if (name === 'desert') {
      const s = seg(220, 120);
      group.add(this.mesh(new THREE.PlaneGeometry(70, 70, s, s).rotateX(-Math.PI / 2), this.material(DESERT_VERT, DESERT_FRAG, u)));
    } else if (name === 'forest') {
      const s = seg(110, 70);
      group.add(this.mesh(new THREE.PlaneGeometry(64, 64, s, s).rotateX(-Math.PI / 2), this.material(FOREST_GROUND_VERT, FOREST_GROUND_FRAG, u)));
      const cone = new THREE.ConeGeometry(0.42, 1, 7, 4);
      cone.translate(0, 0.5, 0);
      const n = this.mobile ? 320 : 700;
      const inst = new THREE.InstancedMesh(cone, this.material(TREE_VERT, TREE_FRAG, u), n);
      const aBin = new Float32Array(n), aSeed = new Float32Array(n);
      const m4 = new THREE.Matrix4(), q = new THREE.Quaternion(), sc = new THREE.Vector3(), p = new THREE.Vector3();
      for (let k = 0; k < n; k++) {
        let r;
        do { r = 3.2 + rng() ** 0.8 * 20; } while ((r > RING - 1.5 && r < RING + 2.0) || (r < RING && rng() < 0.5));
        const a = rng() * Math.PI * 2;
        const inner = r < RING;
        const h = inner ? 0.45 + rng() * 0.8 : 1.4 + rng() * 2.4;
        const w = h * (0.45 + rng() * 0.25);
        p.set(Math.cos(a) * r, GROUND - 0.05, Math.sin(a) * r);
        q.setFromAxisAngle(new THREE.Vector3(0, 1, 0), rng() * 6.28);
        sc.set(w, h, w);
        m4.compose(p, q, sc);
        inst.setMatrixAt(k, m4);
        aBin[k] = Math.min(1, (r - 3) / 20);
        aSeed[k] = rng();
      }
      cone.setAttribute('aBin', new THREE.InstancedBufferAttribute(aBin, 1));
      cone.setAttribute('aSeed', new THREE.InstancedBufferAttribute(aSeed, 1));
      inst.frustumCulled = false;
      this.disposables.push(cone);
      group.add(inst);
      // fireflies
      const fn = this.mobile ? 160 : 360;
      const pos = new Float32Array(fn * 3), seed = new Float32Array(fn);
      for (let k = 0; k < fn; k++) {
        const r = 2.5 + rng() * 15, a = rng() * Math.PI * 2;
        pos.set([Math.cos(a) * r, GROUND + 0.2 + rng() * 2.2, Math.sin(a) * r], k * 3);
        seed[k] = rng();
      }
      const fg = new THREE.BufferGeometry();
      fg.setAttribute('position', new THREE.BufferAttribute(pos, 3));
      fg.setAttribute('aSeed', new THREE.BufferAttribute(seed, 1));
      const flyU = { ...u, uPix: this.shared.uPix };
      const flies = new THREE.Points(fg, this.material(FLY_VERT, FLY_FRAG, flyU, { transparent: true, depthWrite: false, blending: THREE.AdditiveBlending }));
      flies.frustumCulled = false;
      this.disposables.push(fg);
      group.add(flies);
    } else if (name === 'ocean') {
      const s = seg(240, 130);
      Object.assign(u, { uMoon: { value: new THREE.Vector3(0, 1.4, 0) } });
      group.add(this.mesh(new THREE.PlaneGeometry(80, 80, s, s).rotateX(-Math.PI / 2), this.material(OCEAN_VERT, OCEAN_FRAG, u)));
      tick = (dt, live, moon) => { u.uMoon.value.copy(moon); };
    }

    group.visible = false;
    this.scene.add(group);
    this.lands[name] = { group, u, tick };
    return this.lands[name];
  }

  setTarget(name) {
    const t = LANDS.includes(name) ? name : 'cosmos';
    if (t === this.target) return;
    this.target = t;
    this.build(t);
  }

  /** Advance fades and feed audio. Returns 0..1 — how much a landscape is showing. */
  update(dt, spec, live, bg, moon) {
    for (let i = 0; i < 64; i++) this.specData[i] = Math.max(0, Math.min(255, spec[i] * 255));
    this.specTex.needsUpdate = true;
    this.shared.uBgCol.value.copy(bg);

    // One shockwave for every landscape, launched by strong beats.
    const P = this.pulse;
    if (live.kick > 0.55 && P.prevKick <= 0.55) { P.r = 2.5; P.amp = Math.min(1, live.kick); }
    P.prevKick = live.kick;
    P.r += dt * 13;
    P.amp *= Math.exp(-dt * 1.2);
    this.shared.uPulse.value = P.r;
    this.shared.uPulseAmp.value = P.amp;

    let mix = 0;
    for (const [name, land] of Object.entries(this.lands)) {
      const goal = name === this.target ? 1 : 0;
      const f = land.u.uFade;
      const rate = goal ? 0.9 : 1.6;
      f.value += (goal - f.value) * (1 - Math.exp(-dt * rate));
      if (goal && f.value > 0.995) f.value = 1;
      land.group.visible = f.value > 0.004;
      if (land.group.visible && land.tick) land.tick(dt, live, moon);
      if (name !== 'cosmos') mix = Math.max(mix, f.value); // cosmos floats; it doesn't change the camera
    }
    this.mix = mix;
    const tint = new THREE.Color(TINTS[this.target] || 0);
    this.shared.uTint.value.lerp(tint, 1 - Math.exp(-dt * 2));
    this.shared.uFogCol.value.copy(this.shared.uTint.value).multiplyScalar(0.075).add(this.shared.uColMid.value.clone().multiplyScalar(0.05)).add(bg);
    this.skyU.uMix.value = mix;
    this.sky.visible = mix > 0.004;
    return mix;
  }

  dispose() {
    Object.values(this.lands).forEach((l) => this.scene.remove(l.group));
    this.scene.remove(this.sky);
    this.disposables.forEach((d) => d.dispose());
  }
}
