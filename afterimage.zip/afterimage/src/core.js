// AFTERIMAGE core — pure, deterministic logic. No DOM, no WebGL.
// Config, bounds, seeded RNG, mutation engine, seed names, share encoding.

export const CONFIG_VERSION = 3;
export const MODES = ['orb', 'fractal', 'ribbon', 'void'];
export const PALETTES = ['mono', 'ice', 'violet', 'inferno'];
// 'auto' lets the music's mood pick a landscape; 'cosmos' means no landscape.
export const ENVS = ['auto', 'cosmos', 'city', 'desert', 'forest', 'ocean'];
// Colour grade for the whole world. 'auto' reads it from the sound.
export const ATMOS = ['auto', 'natural', 'dark', 'psychedelic'];

// Continuous parameters and their safe bounds.
export const BOUNDS = {
  deform: [0.15, 1],
  motion: [0.05, 1],
  detail: [0, 1],
  glow: [0, 1],
  trail: [0, 1],
  freq: [0.6, 3.4],
  sharp: [0, 1],
  warp: [0, 1],
  flow: [0, 1],
  scale: [0.75, 1.3],
};
export const PARAM_KEYS = Object.keys(BOUNDS);

export const clamp = (v, lo, hi) => Math.min(hi, Math.max(lo, v));
const round3 = (v) => Math.round(v * 1000) / 1000;

// ---------- RNG ----------
export function hashString(str) {
  // FNV-1a 32-bit
  let h = 0x811c9dc5;
  for (let i = 0; i < str.length; i++) {
    h ^= str.charCodeAt(i);
    h = Math.imul(h, 0x01000193);
  }
  return h >>> 0;
}

export function mulberry32(seed) {
  let a = seed >>> 0;
  return function rng() {
    a = (a + 0x6d2b79f5) >>> 0;
    let t = a;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

const range = (rng, lo, hi) => lo + (hi - lo) * rng();
const pick = (rng, arr) => arr[Math.floor(rng() * arr.length) % arr.length];

// ---------- Seed names ----------
const ADJ = ['silver', 'hollow', 'molten', 'quiet', 'feral', 'glass', 'lunar', 'static', 'velvet', 'iron',
  'pale', 'electric', 'drowned', 'ashen', 'liquid', 'broken', 'vast', 'gilded', 'phantom', 'cold',
  'burning', 'slow', 'nocturnal', 'chrome', 'woven', 'distant', 'radiant', 'sunken', 'strange', 'lucid'];
const NOUN = ['moth', 'orbit', 'choir', 'reef', 'signal', 'comet', 'lantern', 'spine', 'tide', 'engine',
  'bloom', 'cathedral', 'ember', 'prism', 'vessel', 'echo', 'nebula', 'shard', 'harbor', 'serpent',
  'monolith', 'halo', 'pulse', 'garden', 'mirror', 'storm', 'circuit', 'veil', 'crown', 'drift'];

export function seedName(rng) {
  return `${pick(rng, ADJ)}-${pick(rng, NOUN)}-${100 + Math.floor(rng() * 900)}`;
}

export function isValidSeed(s) {
  return typeof s === 'string' && /^[a-z]{2,16}-[a-z]{2,16}-\d{1,6}$/.test(s);
}

// ---------- Config ----------
export function defaultConfig() {
  return {
    v: CONFIG_VERSION,
    seed: 'silver-moth-417',
    mode: 'orb',
    palette: 'violet',
    deform: 0.55,
    motion: 0.5,
    detail: 0.6,
    glow: 0.55,
    trail: 0.45,
    freq: 1.4,
    sharp: 0.1,
    warp: 0.15,
    flow: 0.35,
    scale: 1,
    env: 'auto',
    atmo: 'auto',
    gen: 0,
  };
}

/** Clamp every field into range and fill gaps. Never throws. */
export function sanitize(cfg) {
  const d = defaultConfig();
  const out = { v: CONFIG_VERSION };
  out.seed = isValidSeed(cfg && cfg.seed) ? cfg.seed : d.seed;
  out.mode = MODES.includes(cfg && cfg.mode) ? cfg.mode : d.mode;
  out.palette = PALETTES.includes(cfg && cfg.palette) ? cfg.palette : d.palette;
  out.env = ENVS.includes(cfg && cfg.env) ? cfg.env : d.env;
  out.atmo = ATMOS.includes(cfg && cfg.atmo) ? cfg.atmo : d.atmo;
  for (const k of PARAM_KEYS) {
    const v = cfg ? Number(cfg[k]) : NaN;
    out[k] = round3(Number.isFinite(v) ? clamp(v, BOUNDS[k][0], BOUNDS[k][1]) : d[k]);
  }
  const g = cfg ? Math.floor(Number(cfg.gen)) : 0;
  out.gen = Number.isFinite(g) ? clamp(g, 0, 1e6) : 0;
  return out;
}

/** Strict validation for untrusted input (shared links). Returns null if anything is off. */
export function validate(obj) {
  if (!obj || typeof obj !== 'object') return null;
  // Links made by older versions: v1 had no environment, v2 had no atmosphere.
  if (obj.v === 1 && obj.env === undefined) obj = { ...obj, v: 2, env: 'auto' };
  if (obj.v === 2 && obj.atmo === undefined) obj = { ...obj, v: CONFIG_VERSION, atmo: 'auto' };
  if (obj.v !== CONFIG_VERSION) return null;
  if (!ENVS.includes(obj.env) || !ATMOS.includes(obj.atmo)) return null;
  if (!isValidSeed(obj.seed) || !MODES.includes(obj.mode) || !PALETTES.includes(obj.palette)) return null;
  for (const k of PARAM_KEYS) {
    const v = obj[k];
    if (typeof v !== 'number' || !Number.isFinite(v)) return null;
    if (v < BOUNDS[k][0] - 1e-6 || v > BOUNDS[k][1] + 1e-6) return null;
  }
  if (!Number.isInteger(obj.gen) || obj.gen < 0) return null;
  return sanitize(obj);
}

/** Normalised distance between two configs, used to guarantee mutations are visible. */
export function distance(a, b) {
  let d = 0;
  for (const k of PARAM_KEYS) {
    const [lo, hi] = BOUNDS[k];
    d += Math.abs(a[k] - b[k]) / (hi - lo);
  }
  if (a.mode !== b.mode) d += 1;
  if (a.palette !== b.palette) d += 0.6;
  return d;
}

// ---------- Mutation engine ----------
const nudge = (c, k, amt) => { c[k] = clamp(c[k] + amt, BOUNDS[k][0], BOUNDS[k][1]); };
const setR = (c, k, rng, lo = BOUNDS[k][0], hi = BOUNDS[k][1]) => { c[k] = range(rng, lo, hi); };
const span = (k) => BOUNDS[k][1] - BOUNDS[k][0];

export const MUTATIONS = {
  mutate: {
    label: 'Mutate', hint: 'A few coherent changes; keeps the composition',
    apply(c, rng) {
      const keys = ['deform', 'freq', 'sharp', 'warp', 'flow', 'motion', 'scale', 'trail'];
      const n = 2 + Math.floor(rng() * 2);
      for (let i = 0; i < n; i++) {
        const k = keys.splice(Math.floor(rng() * keys.length), 1)[0];
        const dir = rng() < 0.5 ? -1 : 1;
        // push away from walls so the change is felt
        const pos = (c[k] - BOUNDS[k][0]) / span(k);
        const sign = pos > 0.8 ? -1 : pos < 0.2 ? 1 : dir;
        nudge(c, k, sign * span(k) * range(rng, 0.18, 0.35));
      }
      if (rng() < 0.15) c.palette = pick(rng, PALETTES.filter((p) => p !== c.palette));
    },
  },
  melt: {
    label: 'Melt', hint: 'Softer, liquid deformation',
    apply(c, rng) {
      nudge(c, 'flow', range(rng, 0.25, 0.45));
      nudge(c, 'sharp', -range(rng, 0.3, 0.6));
      nudge(c, 'freq', -range(rng, 0.3, 0.7));
      nudge(c, 'deform', range(rng, 0.05, 0.15));
      nudge(c, 'trail', range(rng, 0.05, 0.2));
      if (c.mode === 'fractal') c.mode = rng() < 0.5 ? 'orb' : 'ribbon';
    },
  },
  fracture: {
    label: 'Fracture', hint: 'Sharp, crystalline structure',
    apply(c, rng) {
      nudge(c, 'sharp', range(rng, 0.35, 0.6));
      nudge(c, 'freq', range(rng, 0.4, 0.9));
      nudge(c, 'flow', -range(rng, 0.2, 0.4));
      if (c.mode !== 'fractal' && rng() < 0.4) c.mode = 'fractal';
    },
  },
  warp: {
    label: 'Warp', hint: 'Twist space; break symmetry',
    apply(c, rng) {
      nudge(c, 'warp', range(rng, 0.3, 0.55) * (c.warp > 0.75 ? -1 : 1));
      nudge(c, 'freq', range(rng, -0.6, 0.6));
      nudge(c, 'flow', range(rng, 0.05, 0.2));
      nudge(c, 'motion', range(rng, -0.1, 0.2));
    },
  },
  grow: {
    label: 'Grow', hint: 'Bigger, denser, more detail',
    apply(c, rng) {
      const capped = c.scale > 1.2 && c.detail > 0.9;
      if (capped) { // already huge — regrow from a smaller, denser seed
        c.scale = range(rng, 0.85, 0.95);
        c.freq = clamp(c.freq + 0.8, ...BOUNDS.freq);
      } else {
        nudge(c, 'scale', range(rng, 0.1, 0.2));
        nudge(c, 'detail', range(rng, 0.2, 0.35));
        nudge(c, 'deform', range(rng, 0.08, 0.18));
        nudge(c, 'glow', range(rng, 0.05, 0.12));
      }
    },
  },
  unstable: {
    label: 'Unstable', hint: 'Controlled chaos across many parameters',
    apply(c, rng) {
      for (const k of ['deform', 'freq', 'sharp', 'warp', 'flow', 'motion', 'trail']) {
        nudge(c, k, span(k) * range(rng, -0.45, 0.45));
      }
      c.deform = Math.max(c.deform, 0.35); // never let it collapse
      if (rng() < 0.35) c.mode = pick(rng, MODES.filter((m) => m !== c.mode));
      if (rng() < 0.35) c.palette = pick(rng, PALETTES.filter((p) => p !== c.palette));
    },
  },
  universe: {
    label: 'New universe', hint: 'A completely new seeded world',
    apply(c, rng) {
      c.seed = seedName(rng);
      c.mode = pick(rng, MODES);
      c.palette = pick(rng, PALETTES);
      setR(c, 'deform', rng, 0.35, 0.9);
      setR(c, 'motion', rng, 0.3, 0.8);
      setR(c, 'detail', rng, 0.35, 0.9);
      setR(c, 'glow', rng, 0.35, 0.8);
      setR(c, 'trail', rng, 0.15, 0.75);
      setR(c, 'freq', rng, 0.8, 2.8);
      setR(c, 'sharp', rng);
      setR(c, 'warp', rng, 0, 0.7);
      setR(c, 'flow', rng, 0, 0.8);
      setR(c, 'scale', rng, 0.85, 1.15);
      if (c.mode === 'fractal') c.sharp = Math.max(c.sharp, 0.45);
    },
  },
};

const MIN_DISTANCE = 0.35;

/**
 * Apply a mutation deterministically. Same config + same op => same result.
 * The RNG is derived from seed, generation and op, so a sequence of mutations
 * is reproducible from the starting config.
 */
export function mutate(cfg, op) {
  const m = MUTATIONS[op];
  if (!m) throw new Error(`Unknown mutation: ${op}`);
  const base = sanitize(cfg);
  const rng = mulberry32(hashString(`${base.seed}|${base.gen}|${op}`));
  let next = { ...base };
  m.apply(next, rng);
  next.gen = base.gen + 1;
  next = sanitize(next);
  // Guarantee a visible difference.
  let tries = 0;
  while (distance(base, next) < MIN_DISTANCE && tries < 4) {
    MUTATIONS.mutate.apply(next, rng);
    next = sanitize({ ...next, gen: base.gen + 1 });
    tries++;
  }
  return next;
}

/** Ribbon knot topology derived from the seed. */
export function knotFor(seed) {
  const pairs = [[2, 3], [3, 5], [2, 5], [3, 4], [3, 7], [2, 7]];
  return pairs[hashString(seed) % pairs.length];
}

// ---------- Share encoding ----------
// Compact positional array -> JSON -> base64url. Version is the first element.
const ORDER_V1 = ['seed', 'mode', 'palette', ...PARAM_KEYS, 'gen'];
const ORDER_V2 = [...ORDER_V1, 'env'];
const ORDER = [...ORDER_V2, 'atmo'];

function b64urlEncode(str) {
  const bytes = new TextEncoder().encode(str);
  let bin = '';
  for (const b of bytes) bin += String.fromCharCode(b);
  return btoa(bin).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
}
function b64urlDecode(s) {
  const pad = s.replace(/-/g, '+').replace(/_/g, '/') + '==='.slice((s.length + 3) % 4);
  const bin = atob(pad);
  const bytes = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
  return new TextDecoder().decode(bytes);
}

export function encodeConfig(cfg) {
  const c = sanitize(cfg);
  const arr = [CONFIG_VERSION, ...ORDER.map((k) => c[k])];
  return b64urlEncode(JSON.stringify(arr));
}

/** Returns a validated config or null. Never throws. */
export function decodeConfig(code) {
  try {
    if (typeof code !== 'string' || code.length > 600 || !/^[A-Za-z0-9_-]+$/.test(code)) return null;
    const arr = JSON.parse(b64urlDecode(code));
    if (!Array.isArray(arr)) return null;
    const order = arr[0] === 1 ? ORDER_V1 : arr[0] === 2 ? ORDER_V2 : ORDER;
    if (arr.length !== order.length + 1) return null;
    const obj = { v: arr[0] };
    order.forEach((k, i) => { obj[k] = arr[i + 1]; });
    return validate(obj);
  } catch {
    return null;
  }
}

// ---------- History ----------
export class History {
  constructor(initial, cap = 40) {
    this.items = [{ config: initial, thumb: null, op: 'start' }];
    this.index = 0;
    this.cap = cap;
  }
  get current() { return this.items[this.index]; }
  push(config, op) {
    this.items = this.items.slice(0, this.index + 1);
    this.items.push({ config, thumb: null, op });
    if (this.items.length > this.cap) this.items.shift();
    this.index = this.items.length - 1;
    return this.current;
  }
  canUndo() { return this.index > 0; }
  canRedo() { return this.index < this.items.length - 1; }
  undo() { if (this.canUndo()) this.index--; return this.current; }
  redo() { if (this.canRedo()) this.index++; return this.current; }
  jump(i) { if (i >= 0 && i < this.items.length) this.index = i; return this.current; }
}

// ---------- Mood → environment ----------
// Rolling song statistics, each 0..1:
//   e = energy (loudness), b = brightness (spectral centroid),
//   o = busyness (onsets per second), w = bass weight (bass vs mids).
export const MOOD_PROTOS = {
  city:   { e: 0.72, b: 0.62, o: 0.78, w: 0.55 },
  desert: { e: 0.52, b: 0.28, o: 0.36, w: 0.72 },
  forest: { e: 0.36, b: 0.56, o: 0.45, w: 0.34 },
  ocean:  { e: 0.22, b: 0.30, o: 0.12, w: 0.50 },
};
const MOOD_W = { e: 1.2, b: 1.0, o: 1.3, w: 0.8 };

export function moodScores(s) {
  const out = {};
  for (const [env, p] of Object.entries(MOOD_PROTOS)) {
    let d = 0;
    for (const k of Object.keys(MOOD_W)) d += MOOD_W[k] * (s[k] - p[k]) ** 2;
    out[env] = -Math.sqrt(d);
  }
  return out;
}

export function pickMood(s) {
  const sc = moodScores(s);
  return Object.keys(sc).reduce((a, b) => (sc[b] > sc[a] ? b : a));
}

/** Picks a landscape after a few seconds of listening and changes it only when the song clearly changes. */
export class MoodTracker {
  constructor({ warmup = 4, confirm = 5, dwell = 12, pick = pickMood } = {}) {
    Object.assign(this, { warmup, confirm, dwell, pick });
    this.reset();
  }
  reset() {
    this.env = null;
    this.listened = 0;
    this.sinceSwitch = 0;
    this.candidate = null;
    this.candidateTime = 0;
  }
  update(stats, dt) {
    this.listened += dt;
    this.sinceSwitch += dt;
    if (this.listened < this.warmup) return this.env;
    const best = this.pick(stats);
    if (!this.env) { this.env = best; this.sinceSwitch = 0; return this.env; }
    if (best === this.env) { this.candidate = null; this.candidateTime = 0; return this.env; }
    if (best !== this.candidate) { this.candidate = best; this.candidateTime = 0; }
    this.candidateTime += dt;
    if (this.candidateTime >= this.confirm && this.sinceSwitch >= this.dwell) {
      this.env = best;
      this.sinceSwitch = 0;
      this.candidate = null;
      this.candidateTime = 0;
    }
    return this.env;
  }
}

// ---------- Atmosphere ----------
// Song character, each 0..1:
//   e = energy, b = brightness, flat = spectral flatness (noise and distortion vs. clear tones),
//   vari = how much the sound changes over tens of seconds, long = song length (files only).
const ss = (a, b, x) => { const t = clamp((x - a) / (b - a), 0, 1); return t * t * (3 - 2 * t); };

export function atmosphereScores(s) {
  // Harsh and loud (black metal, industrial, noise), or heavy and murky (doom, dark ambient).
  const harsh = ss(0.2, 0.36, s.flat) * ss(0.4, 0.65, s.e);
  const murky = ss(0.4, 0.2, s.b) * ss(0.45, 0.25, s.e) * ss(0.35, 0.15, s.vari);
  const dark = Math.max(harsh, murky);
  // Clear tones that keep morphing over a long time (psychedelic, progressive).
  const psychedelic = ss(0.3, 0.6, s.vari) * ss(0.3, 0.16, s.flat) * (0.75 + 0.25 * (s.long || 0));
  return { dark, psychedelic };
}

export function classifyAtmosphere(s) {
  const { dark, psychedelic } = atmosphereScores(s);
  if (dark >= 0.5 && dark >= psychedelic) return 'dark';
  if (psychedelic >= 0.5) return 'psychedelic';
  return 'natural';
}

// ---------- Journey ----------
const avg = (a, i0, i1) => { let s = 0, n = 0; for (let i = Math.max(0, i0); i < Math.min(a.length, i1); i++) { s += a[i]; n++; } return n ? s / n : 0; };

/**
 * Split a song into chapters, each with its own landscape.
 * perSec: { e, b, o, w } arrays sampled once per second (0..1).
 * Returns [{ start, end, env, energy }] covering the whole song.
 */
export function buildJourney(perSec, { minLen = 20, win = 8, threshold = 0.1 } = {}) {
  const n = perSec.e.length;
  if (!n) return [];
  const sm = (a) => a.map((_, i) => avg(a, i - 3, i + 3));
  const E = sm(perSec.e), B = sm(perSec.b), O = sm(perSec.o);
  const nov = new Float32Array(n);
  for (let t = win; t < n - win; t++) {
    nov[t] = Math.hypot(avg(E, t - win, t) - avg(E, t, t + win), avg(B, t - win, t) - avg(B, t, t + win), 0.8 * (avg(O, t - win, t) - avg(O, t, t + win)));
  }
  const cuts = [0];
  for (let t = win; t < n - win; t++) {
    if (nov[t] < threshold) continue;
    let peak = true;
    for (let k = t - 6; k <= t + 6; k++) if (k !== t && k >= 0 && k < n && nov[k] > nov[t]) { peak = false; break; }
    if (peak && t - cuts[cuts.length - 1] >= minLen && n - t >= minLen) cuts.push(t);
  }
  cuts.push(n);
  let out = [];
  for (let i = 0; i < cuts.length - 1; i++) {
    const [a, b] = [cuts[i], cuts[i + 1]];
    const stats = { e: avg(perSec.e, a, b), b: avg(perSec.b, a, b), o: avg(perSec.o, a, b), w: avg(perSec.w, a, b) };
    const env = pickMood(stats);
    const prev = out[out.length - 1];
    if (prev && prev.env === env) { prev.end = b; prev.energy = (prev.energy + stats.e) / 2; continue; }
    out.push({ start: a, end: b, env, energy: stats.e });
  }
  return out;
}

export function chapterAt(journey, t) {
  if (!journey || !journey.length) return -1;
  for (let i = 0; i < journey.length; i++) if (t < journey[i].end) return i;
  return journey.length - 1;
}
