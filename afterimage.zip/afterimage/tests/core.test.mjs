import assert from 'node:assert/strict';
import { test } from 'node:test';
import {
  defaultConfig, mutate, MUTATIONS, BOUNDS, PARAM_KEYS, MODES, PALETTES,
  encodeConfig, decodeConfig, sanitize, distance, History, knotFor,
} from '../src/core.js';

const ops = Object.keys(MUTATIONS);

test('mutations are deterministic', () => {
  for (const op of ops) {
    assert.deepEqual(mutate(defaultConfig(), op), mutate(defaultConfig(), op));
  }
  const seq = ['melt', 'warp', 'universe', 'fracture', 'mutate', 'grow', 'unstable'];
  const run = () => seq.reduce((c, op) => mutate(c, op), defaultConfig());
  assert.deepEqual(run(), run());
});

test('mutations stay in bounds and are visible, over long random walks', () => {
  let c = defaultConfig();
  for (let i = 0; i < 3000; i++) {
    const op = ops[i % ops.length === 0 ? 6 : (i * 7) % ops.length];
    const n = mutate(c, op);
    for (const k of PARAM_KEYS) {
      assert.ok(n[k] >= BOUNDS[k][0] && n[k] <= BOUNDS[k][1], `${op} ${k}=${n[k]}`);
    }
    assert.ok(MODES.includes(n.mode) && PALETTES.includes(n.palette));
    assert.ok(n.deform >= 0.15, 'scene never disappears');
    assert.ok(distance(c, n) > 0.2, `${op} too subtle at step ${i}: ${distance(c, n)}`);
    assert.equal(n.gen, c.gen + 1);
    c = n;
  }
});

test('new universe changes the seed', () => {
  const a = defaultConfig();
  assert.notEqual(mutate(a, 'universe').seed, a.seed);
});

test('share encoding round-trips', () => {
  let c = defaultConfig();
  for (let i = 0; i < 50; i++) {
    c = mutate(c, ops[i % ops.length]);
    const code = encodeConfig(c);
    assert.match(code, /^[A-Za-z0-9_-]+$/);
    assert.ok(code.length < 220, `code length ${code.length}`);
    assert.deepEqual(decodeConfig(code), c);
  }
});

test('invalid share codes fail safely', () => {
  const bad = ['', 'abc', '!!!', 'x'.repeat(1000), btoa('[2,"a"]'), btoa('{"v":1}'),
    Buffer.from(JSON.stringify([1, 'silver-moth-417', 'orb', 'mono', 9, 0.5, 0.5, 0.5, 0.5, 1, 0, 0, 0, 1, 0])).toString('base64url'),
    Buffer.from(JSON.stringify([1, '<script>', 'orb', 'mono', 0.5, 0.5, 0.5, 0.5, 0.5, 1, 0, 0, 0, 1, 0])).toString('base64url'),
    Buffer.from(JSON.stringify([1, 'silver-moth-417', 'cube', 'mono', 0.5, 0.5, 0.5, 0.5, 0.5, 1, 0, 0, 0, 1, 0])).toString('base64url'),
    Buffer.from(JSON.stringify([1, 'silver-moth-417', 'orb', 'mono', 0.5, 0.5, 0.5, 0.5, 0.5, 1, 0, 0, 0, 1, -1])).toString('base64url')];
  for (const b of bad) assert.equal(decodeConfig(b), null, b);
});

test('v1 links (before environments) still open', () => {
  const v1 = Buffer.from(JSON.stringify([1, 'silver-moth-417', 'fractal', 'ice', 0.5, 0.5, 0.5, 0.5, 0.5, 1.4, 0.2, 0.1, 0.3, 1, 3])).toString('base64url');
  const c = decodeConfig(v1);
  assert.ok(c);
  assert.equal(c.mode, 'fractal');
  assert.equal(c.env, 'auto');
  assert.equal(c.v, 3);
  assert.equal(c.atmo, 'auto');
});

test('environment survives mutations and sharing', () => {
  let c = { ...defaultConfig(), env: 'desert' };
  for (const op of ops) c = mutate(c, op);
  assert.equal(c.env, 'desert');
  assert.equal(decodeConfig(encodeConfig(c)).env, 'desert');
  const bad = Buffer.from(JSON.stringify([2, 'silver-moth-417', 'orb', 'mono', 0.5, 0.5, 0.5, 0.5, 0.5, 1, 0, 0, 0, 1, 0, 'mars'])).toString('base64url');
  assert.equal(decodeConfig(bad), null);
});

test('sanitize clamps garbage', () => {
  const s = sanitize({ deform: 99, motion: -5, mode: 'x', seed: 3, freq: 'NaN' });
  assert.equal(s.deform, 1);
  assert.equal(s.motion, BOUNDS.motion[0]);
  assert.equal(s.mode, 'orb');
});

test('history undo/redo/truncate', () => {
  const h = new History(1);
  h.push(2); h.push(3);
  assert.equal(h.undo().config, 2);
  assert.equal(h.redo().config, 3);
  h.undo(); h.push(4);
  assert.equal(h.canRedo(), false);
  assert.deepEqual(h.items.map((i) => i.config), [1, 2, 4]);
});

test('knot is stable per seed', () => {
  assert.deepEqual(knotFor('silver-moth-417'), knotFor('silver-moth-417'));
});

test('mood picks the matching landscape', async () => {
  const { pickMood, MOOD_PROTOS } = await import('../src/core.js');
  for (const [env, p] of Object.entries(MOOD_PROTOS)) assert.equal(pickMood(p), env);
  assert.equal(pickMood({ e: 0.9, b: 0.7, o: 0.95, w: 0.5 }), 'city');
  assert.equal(pickMood({ e: 0.15, b: 0.2, o: 0.05, w: 0.5 }), 'ocean');
});

test('mood tracker waits, then holds steady', async () => {
  const { MoodTracker, MOOD_PROTOS } = await import('../src/core.js');
  const m = new MoodTracker();
  const step = (s, secs) => { let r; for (let t = 0; t < secs; t += 0.1) r = m.update(s, 0.1); return r; };
  assert.equal(step(MOOD_PROTOS.city, 3), null);
  assert.equal(step(MOOD_PROTOS.city, 2), 'city');
  assert.equal(step(MOOD_PROTOS.ocean, 4), 'city', 'brief change ignored');
  assert.equal(step(MOOD_PROTOS.ocean, 8), 'ocean', 'sustained change switches');
});

test('v2 links (before atmosphere) still open', async () => {
  const v2 = Buffer.from(JSON.stringify([2, 'silver-moth-417', 'orb', 'ice', 0.5, 0.5, 0.5, 0.5, 0.5, 1.4, 0.2, 0.1, 0.3, 1, 3, 'ocean'])).toString('base64url');
  const c = decodeConfig(v2);
  assert.ok(c);
  assert.equal(c.env, 'ocean');
  assert.equal(c.atmo, 'auto');
  const round = decodeConfig(encodeConfig({ ...c, atmo: 'dark' }));
  assert.equal(round.atmo, 'dark');
});

test('atmosphere reads harsh, murky, morphing and plain music', async () => {
  const { classifyAtmosphere } = await import('../src/core.js');
  assert.equal(classifyAtmosphere({ e: 0.8, b: 0.6, flat: 0.45, vari: 0.2 }), 'dark', 'black-metal-like wall of noise');
  assert.equal(classifyAtmosphere({ e: 0.2, b: 0.12, flat: 0.12, vari: 0.08 }), 'dark', 'doom / dark ambient');
  assert.equal(classifyAtmosphere({ e: 0.5, b: 0.45, flat: 0.1, vari: 0.75, long: 1 }), 'psychedelic', 'long, tonal, ever-changing');
  assert.equal(classifyAtmosphere({ e: 0.55, b: 0.5, flat: 0.12, vari: 0.2 }), 'natural', 'ordinary pop');
});

test('journey splits a calm intro from a loud section', async () => {
  const { buildJourney, chapterAt } = await import('../src/core.js');
  const n = 140;
  const seg = (calm, loud) => Array.from({ length: n }, (_, i) => (i < 60 ? calm : loud));
  const j = buildJourney({ e: seg(0.2, 0.75), b: seg(0.3, 0.62), o: seg(0.1, 0.8), w: seg(0.5, 0.55) });
  assert.equal(j.length, 2);
  assert.equal(j[0].env, 'ocean');
  assert.equal(j[1].env, 'city');
  assert.ok(Math.abs(j[1].start - 60) <= 6, `cut at ${j[1].start}`);
  assert.equal(j[1].end, n);
  assert.equal(chapterAt(j, 10), 0);
  assert.equal(chapterAt(j, 100), 1);
  const flat = buildJourney({ e: Array(90).fill(0.7), b: Array(90).fill(0.6), o: Array(90).fill(0.75), w: Array(90).fill(0.55) });
  assert.equal(flat.length, 1, 'a steady song stays one chapter');
});
