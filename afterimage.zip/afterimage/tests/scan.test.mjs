import assert from 'node:assert/strict';
import { test } from 'node:test';
import { fft, flatness, scanSong } from '../src/scan.js';

const SR = 22050;
function rng(seed) { let a = seed; return () => { a = (a * 1664525 + 1013904223) >>> 0; return a / 4294967296; }; }

test('fft finds a pure tone', () => {
  const re = new Float32Array(2048), im = new Float32Array(2048);
  for (let i = 0; i < 2048; i++) re[i] = Math.sin((2 * Math.PI * 64 * i) / 2048);
  fft(re, im);
  const mags = Array.from({ length: 1024 }, (_, k) => Math.hypot(re[k], im[k]));
  assert.equal(mags.indexOf(Math.max(...mags)), 64);
});

test('flatness separates noise from tones', () => {
  const r = rng(1);
  const noise = Float32Array.from({ length: 512 }, () => 0.5 + r());
  const tone = new Float32Array(512); tone[40] = 1; tone[80] = 0.5;
  assert.ok(flatness(noise, 0, 512) > 0.7);
  assert.ok(flatness(tone, 0, 512) < 0.05);
});

test('scan maps a soft intro and a harsh noisy section into two chapters', async () => {
  const secs = 90, n = SR * secs, x = new Float32Array(n), r = rng(7);
  for (let i = 0; i < n; i++) {
    const t = i / SR;
    if (t < 45) {
      x[i] = 0.06 * (Math.sin(2 * Math.PI * 220 * t) + Math.sin(2 * Math.PI * 277 * t) + Math.sin(2 * Math.PI * 330 * t)) * (0.6 + 0.4 * Math.sin(t * 0.5));
    } else {
      const beat = (t * 3) % 1;
      const kick = beat < 0.12 ? Math.sin(2 * Math.PI * 60 * beat) * (1 - beat / 0.12) : 0;
      x[i] = 0.45 * (r() * 2 - 1) + 0.5 * kick;
    }
  }
  const t0 = Date.now();
  const map = await scanSong(x, SR);
  const ms = Date.now() - t0;
  console.log('scan ms', ms, JSON.stringify({ stats: map.stats, atmo: map.atmoStats, env: map.env, atmoPick: map.atmo, journey: map.journey }));
  assert.ok(map.journey.length >= 2, 'found a chapter change');
  assert.ok(Math.abs(map.journey[1].start - 45) <= 8, `cut near 45s, got ${map.journey[1].start}`);
  assert.notEqual(map.journey[0].env, map.journey[map.journey.length - 1].env);
  assert.equal(map.envelope.length, 240);
  assert.ok(ms < 8000, 'fast enough');
});
